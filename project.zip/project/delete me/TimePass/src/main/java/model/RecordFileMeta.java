package model;

import java.io.File;

public class RecordFileMeta extends File {
    private String fileName;
    private String rejectionLevel;

    public RecordFileMeta(String pathname, String fileName, String rejectionLevel) {
        super(pathname);
        this.fileName = fileName;
        this.rejectionLevel = rejectionLevel;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getRejectionLevel() {
        return rejectionLevel;
    }

    public void setRejectionLevel(String rejectionLevel) {
        this.rejectionLevel = rejectionLevel;
    }
}
