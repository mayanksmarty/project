package service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.*;

class Validator {
    public enum DataTypes {
        INTEGER, FLOAT, STRING, DOUBLE, CHARACTER, LONG
    }

    public boolean validateDataType(Object fieldValue, DataTypes b) {
        String arr[] = fieldValue.getClass().getName().toString().toUpperCase().split(Pattern.quote("."));
        return arr[arr.length-1].equals(b.toString());
    }

    public <E> boolean validateLength(E fieldValue, int maximumLength) {
        if (fieldValue.getClass().getName() == "java.lang.Float" || fieldValue.getClass().getName() == "java.lang.Double") {
            if (fieldValue.toString().endsWith(".0")) {
                return fieldValue.toString().replace(".0", "").trim().length() <= maximumLength;
            }
            return fieldValue.toString().length() <= maximumLength;
        }
        return fieldValue.toString().length() <= maximumLength && fieldValue.toString().length() > 0;
    }

    public <E> boolean validateSpecialCharacters(E fieldValue, char[] specialCharacters) {
        for (char specialCharacter: specialCharacters) {
            if (fieldValue.toString().contains(Character.toString(specialCharacter))) {
                return false;
            }
        }
        return true;
    }

    public <E> boolean checkDomain(E fieldValue, E[] domainList) {
        for (E listValue: domainList) {
            if (listValue == fieldValue) {
                return true;
            }
        }
        return false;
    }

    public boolean validateFormat(String date) {
        String format = "dd/MMM/yyyy";
        DateFormat dateFormat= new SimpleDateFormat(format);
        try {
            dateFormat.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean validatePattern(String input, String pattern) {
        return Pattern.matches(pattern, input);
    }

    public boolean validateEmail(String emailAddress) {
        return Pattern.matches("[A-Za-z0-9_]+@([A-Za-z0-9_]+[.])+[A-Za-z0-9_]+", emailAddress);
    }
}
