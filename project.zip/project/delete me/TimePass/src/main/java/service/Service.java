package service;

import database.DAO;
import model.Record;
import model.RecordFileMeta;

import java.io.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;

public class Service {
    private DAO dao;
    private ArrayList<RecordFileMeta> fileMetaList;
    private HashMap<Integer, Command> map;
    private Validator validator;
    private Record record;

    public Service() {
        dao = new DAO();
        validator = new Validator();
        fileMetaList = dao.getFileMeta();
        map = new HashMap<>();
        populateMap();
    }

    private void populateMap() {
        map.put(0, input -> {
            if (validator.validateLength(input, 10)) {
                record.setCustomerCode(input);
                return true;
            }
            return false;
        });
        map.put(1, input -> {
            if (validator.validateLength(input, 30) && validator.validatePattern(input, "[A-Za-z0-9 ]+")) {
                record.setCustomerName(input);
                return true;
            }
            return false;
        });
        map.put(2, input -> {
            if (validator.validateLength(input, 100)) {
                record.setCustomerAddress1(input);
                return true;
            }
            return false;
        });
        map.put(3, input -> {
            if (validator.validateLength(input, 100)) {
                 record.setCustomerAddress2(input);
                 return true;
            }
            return false;
        });
        map.put(4, input -> {
            if (input.length() == 6 && validator.validatePattern(input, "[0-9]+")) {
                record.setCustomerPinCode(Integer.parseInt(input));
                return true;
            }
            return false;
        });
        map.put(5, input -> {
            if (validator.validateLength(input, 100) && validator.validateEmail(input)) {
                record.setEmailAddress(input);
                return true;
            }
            return false;
        });
        map.put(6, input -> {
            if (validator.validateLength(input, 20) && validator.validatePattern(input, "[0-9]+")) {
                record.setContactNumber(input);
                return true;
            }
            return false;
        });
        map.put(7, input -> {
            if (validator.validateLength(input, 100)) {
                record.setPrimaryContactPerson(input);
                return true;
            }
            return false;
        });
        map.put(8, input -> {
            if (validator.validateLength(input, 1) && validator.validatePattern(input, "[ADMNR]")) {
                record.setRecordStatus(input);
                return true;
            }
            return false;
        });
        map.put(9, input -> {
            if (validator.validateLength(input, 1) && validator.validatePattern(input, "[AI]")) {
                record.setFlag(input);
                return true;
            }
            return false;
        });
        map.put(10, input -> {
            if (input.length() > 0 && validator.validateFormat(input)) {
                record.setCreatedDate(getDate(input));
                return true;
            }
            return false;
        });
        map.put(11, input -> {
            if (validator.validateLength(input, 30)) {
                record.setCreatedBy(input);
                return true;
            }
            return false;
        });
        map.put(12, input -> {
            if (input.length() > 0 && validator.validateFormat(input)) {
                record.setModifiedDate(getDate(input));
                return true;
            }
            return false;
        });
        map.put(13, input -> {
            if (validator.validateLength(input, 30)) {
                record.setModifiedBy(input);
                return true;
            }
            return false;
        });
        map.put(14, input -> {
            if (input.length() > 0 && validator.validateFormat(input)) {
                record.setAuthorizedDate(getDate(input));
                return true;
            }
            return false;
        });
        map.put(15, input -> {
            if (validator.validateLength(input, 30)) {
                record.setAuthorizedBy(input);
                return true;
            }
            return false;
        });
    }

    public Date getDate(String input) {
        Date resultDate = Date.valueOf(LocalDate.now());
        DateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
        try {
            java.util.Date date = dateFormat.parse(input);
            dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            resultDate = Date.valueOf(dateFormat.format(date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return resultDate;
    }

    public void validateFiles() {
        int invalidFiles = 0;
        for (RecordFileMeta recordFileMeta: fileMetaList) {
            String fileName = recordFileMeta.getFileName();

            if (!fileName.substring(recordFileMeta.getFileName().lastIndexOf('.') + 1).equals("txt") && !recordFileMeta.exists()) {
                invalidFiles++;
                fileMetaList.remove(recordFileMeta);
            }
        }
        if (invalidFiles > 0) {
            //  throws some exception here
        }
    }

    public void insertData() {
        FileReader fileReader;
        BufferedReader bufferedReader;
        String row;
        String fieldValues[];

        for (RecordFileMeta recordFileMeta: fileMetaList) {
            boolean successful = true;
            try {
                fileReader = new FileReader(recordFileMeta.getPath());
                bufferedReader = new BufferedReader(fileReader);
                row = bufferedReader.readLine();
                while (row != null) {
                    fieldValues = row.split(Pattern.quote("~"));
                    successful = insertRecord(fieldValues) && successful;
                    row = bufferedReader.readLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            if (successful || recordFileMeta.getRejectionLevel().equals("R")) {
                dao.commit();
            }
        }

    }

    private boolean insertRecord(String[] fieldValues) {
        int index = 0;
        boolean successful = true;
        record = new Record();
        for (; index < fieldValues.length; index++) {
            if(!map.get(index).executeSetter(fieldValues[index])) {
                successful = false;
            }
        }

        if (successful) {
            dao.insertRecord(record);
        }
        return successful;
    }
}
