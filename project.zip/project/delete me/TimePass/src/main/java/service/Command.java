package service;

@FunctionalInterface
public interface Command {
    boolean executeSetter(String input);
}
