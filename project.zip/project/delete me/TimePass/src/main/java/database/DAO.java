package database;

import model.Record;
import model.RecordFileMeta;

import java.sql.*;
import java.util.ArrayList;

public class DAO {
    PreparedStatement insertRecord;
    Connection con;

    public DAO() {
        con = Connect.getConnection();
        try {
            con.setAutoCommit(false);
            insertRecord = con.prepareStatement("insert into customer_master values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertRecord(Record record) {
        Connection connection = Connect.getConnection();
        try {
            insertRecord.setInt(1, record.getCustomerId());
            insertRecord.setString(2, record.getCustomerCode());
            insertRecord.setString(3, record.getCustomerName());
            insertRecord.setString(4, record.getCustomerAddress1());
            insertRecord.setString(5, record.getCustomerAddress2());
            insertRecord.setInt(6, record.getCustomerPinCode());
            insertRecord.setString(7, record.getEmailAddress());
            insertRecord.setString(8, record.getContactNumber());
            insertRecord.setString(9, record.getPrimaryContactPerson());
            insertRecord.setString(10, record.getRecordStatus());
            insertRecord.setString(11, record.getFlag());
            insertRecord.setDate(12, record.getCreatedDate());
            insertRecord.setString(13, record.getCreatedBy());
            insertRecord.setDate(14, record.getModifiedDate());
            insertRecord.setString(15, record.getModifiedBy());
            insertRecord.setDate(16, record.getAuthorizedDate());
            insertRecord.setString(17, record.getAuthorizedBy());
            insertRecord.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void commit() {
        try {
            con.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<RecordFileMeta> getFileMeta() {
        String query = "select * from system_parameters";
        ArrayList<RecordFileMeta> recordFileList = new ArrayList<>();
        Connection connection = Connect.getConnection();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                RecordFileMeta fileMeta = new RecordFileMeta(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3));
                recordFileList.add(fileMeta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return recordFileList;
    }
}
