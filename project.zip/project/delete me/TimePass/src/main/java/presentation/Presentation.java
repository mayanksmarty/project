package presentation;

import service.Service;

public class Presentation {
    private Service service;

    public Presentation() {
        service = new Service();
    }
    public void validateFiles() {
        service.validateFiles();
    }
    public void insertData() {
        service.insertData();
    }
}
