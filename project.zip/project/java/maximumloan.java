import java.lang.*;
class MaximumLoan
{
public static void main(String args[])
{
double Maximumloan,emi;
int salary=50000,rate=10,time=10;
emi=salary - ((0.5* salary) + (0.2 * salary));
Maximumloan=emi* Math.pow((1+rate),10)/(Math.pow((1+rate),time));
 System.out.println("Maximumloan="+Maximumloan);
}
}

