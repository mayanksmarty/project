import java.lang.*;
class Installment
{
double rate=0.12;
double time=10;
double installmentAmount;
int residualvalue=0;
double principle=100000;
double numberInstallment=4;

public void fun()
{
installmentAmount=(principle*(rate/time)-residualvalue*(rate/time)/Math.pow((1+rate/time),numberInstallment))/((1-1/(Math.pow((1+rate/time),numberInstallment))));
System.out.println(installmentAmount);

}

}