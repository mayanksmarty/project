class student 
{
private int studentId;
private  String studentName;
private  double studentMarks;
 
void set(int id, String name,double marks)
{
this.studentId=id;
this.studentName=name;
this.studentMarks=marks;
}
void showdata()
{
System.out.println(studentId+" "+studentName+" "+studentMarks);
}
}
