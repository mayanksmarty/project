import java.util.*;
class CustomerLoan
{
int customerId;
String customerName;
String dateofbirth;
String emailAddress;
String profession;
double totalMonthlyexpense;
String designation;
String companyname;
double monthlyIncome;
public void insert()
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the customerId");
customerId=sc.nextInt();
System.out.println("Enter the customerName");
customerName=sc.nextLine();
System.out.println("Enter the dateofbirth");
dateofbirth=sc.nextLine();
System.out.println("Enter the emailAdress");
emailAddress=sc.nextLine();
System.out.println("Enter the profession");
profession=sc.nextLine();
System.out.println("Enter the totalMonthlyexpense");
totalMonthlyexpense=sc.nextDouble();
System.out.println("Enter the designation");
designation=sc.nextLine();
System.out.println("Enter the companyname");
companyname=sc.nextLine();
System.out.println("Enter the Monthly Income");
monthlyIncome=sc.nextDouble();
}

public void calculate()
{
double dbr;
double maximumEmi;
double rate=.12;
dbr=totalMonthlyexpense/monthlyIncome;
System.out.println("DBR will be"+dbr);
maximumEmi=monthlyIncome - ((0.5* monthlyIncome) + (0.2 * monthlyIncome));
System.out.println("maximumEmi"+maximumEmi);
}
}










