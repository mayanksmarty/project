class Main
{
public static void main(String args[])
{
Installment ins =new Installment();
int installmentno;
double openingbalance=ins.principle;
 double rate=ins.rate;
 double time=ins.numberInstallment;
double interest;
double principle;
ins.fun();
 double installmentAmount=ins.installmentAmount;
for(installmentno=1;installmentno<=time;installmentno++)
{
interest= (openingbalance * (rate/12) )  ;

principle=installmentAmount-interest;

System.out.println("the installment for "+installmentno+" year with insterst and principle"+interest+" and "+principle+"and their installment"+openingbalance );
openingbalance=openingbalance-principle;
}

}
}






