class MaincustomerLoan{
public static void main(String arg[])
{
CustomerLoan cl=new CustomerLoan();
cl.insert();
cl.calculate();
}
}

