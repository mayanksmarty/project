class Mainclass{

public static void main(String arg[])
{

student std;
std =new student();
std.set(34,"abc",5757.98);
std.showdata();

}

}