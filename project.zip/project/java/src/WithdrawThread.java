public class WithdrawThread  extends Thread{
    Account account;
    WithdrawThread(Account ac){
        account = ac;
    }
    public void run(){
        account.withdraw(5000);
    }
}
class DepositThread extends Thread{
    Account account;

    public DepositThread( Account account) {
        this.account = account;
    }
    public void run(){
        account.deposit(6000);
    }
}

