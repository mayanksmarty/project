import java.time.LocalDate;
import java.util.*;

public class Loanmain2 {
 private int day;
 private int month;
 private int year;
 public int getDay() {
  return day;
 }
 public void setDay(int day) {
  this.day = day;
 }

 public int getMonth() {
  return month;
 }

 public void setMonth(int month) {
  this.month = month;
 }

 public int getYear() {
  return year;
 }

 public void setYear(int year) {
  this.year = year;
 }
    public static void main(String args[])
    {

       Loan2 l = new Loan2(Loan2.laonstatus.Pending);
       Loanmain2 l1=new Loanmain2();
       System.out.println("Loanid is- "+l.getLoanId());

        Scanner sc=new Scanner(System.in);
      //  System.out.println("enter the loan id");
       // l.setLoanId(sc.nextInt());




     System.out.println("enter Loan Type");
        l.setLoanType(sc.nextLine());
        System.out.println("enter Loan Amount");
        l.setLoanAmount(sc.nextDouble());
        System.out.println("enter the tenure");
        l.setTenure(sc.nextInt());
        System.out.println("enter the roi");
        l.setRoi(sc.nextDouble());

        System.out.println("enter repayment frequency");
        l.setRepaymentfrequency(sc.nextInt());
        System.out.println("enter the emi");
        l.setEmiperMonth(sc.nextDouble());

        System.out.println("enter day");
        l1.setDay(sc.nextInt());
        System.out.println("enter month");
        l1.setMonth(sc.nextInt());
        System.out.println("enter year");
        l1.setYear(sc.nextInt());
        LocalDate ld= LocalDate.of(l1.getYear(),l1.getMonth(),l1.getDay());

        System.out.println("the disbursal date will be");
        l.setLoandisbursalDate(ld);
        System.out.println("enter monthly expanse");
         l.setMonthlyexpanse(sc.nextDouble());
         System.out.println("enter monthlyincome");
         l.setMonthlyincome(sc.nextDouble());

         l.calcemi();
        l.calcloanamount();
    //   l.repymentschedule();
     //    l.calcpenalty();












 }
}















































































































































































































































































































































































































































