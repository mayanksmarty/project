public class TestSync {
    public static void main(String[] args) throws InterruptedException {
        Account ac = new Account();
        ac.balance = 10000;

        WithdrawThread wt = new WithdrawThread(ac);
        wt.start();

        DepositThread dt = new DepositThread(ac);
        dt.start();
        dt.join();
        wt.join();
        System.out.println(ac.balance);
    }
}
