import java.time.LocalDate;
import java.util.*;
public class Main {
    public static void main(String args[])
    {
        LocalDate ld= LocalDate.of(1999,8,21 );
        Customerloan1 c=new Customerloan1 (ld,"mayankmittal211@gmail.com");
        Scanner sc=new Scanner(System.in);
        System.out.println("customer id is"+c.getCustomerId());
        System.out.println("enter company name");
        c.setCompanyname(sc.nextLine());
        System.out.println("enter customer Name");
        c.setCustomerName(sc.nextLine());
        System.out.println("enter customer contact no");
        c.setContactno(sc.nextLine());
        System.out.println("enter the profession");
        c.setProfession(sc.nextLine());
        System.out.println("enter the customer designation");
        c.setDesignation(sc.nextLine());
        System.out.println("enter the salary");
        c.setMonthlyIncome(sc.nextDouble());
        System.out.println("enter the monthly expense");
        c.setTotalMonthlyexpense(sc.nextDouble());

        System.out.println(c.dbr());
        System.out.println(c.emi());



    }

}

