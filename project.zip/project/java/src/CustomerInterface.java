/*
import java.util.Scanner;

public class CustomerInterface {
    public static void main(String[] args) {
      //  Static int count=0;

        Cust cust[] = new Cust[100];
       // cust[0]=new Cust(6156,12);
        */
/*Scanner sc = new Scanner(System.in);
        int age;
        double salary;
        String name;
        System.out.println("enter the age");
        age = sc.nextInt();
        System.out.println("enter the name");
        salary = sc.nextDouble();
        System.out.println("enter the salary");
        name = sc.nextLine();
        *//*

        System.out.println(cust[0].getAge());




        CustomerInterface cust1=new CustomerInterface();

    }
}
*/
