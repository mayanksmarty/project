package linklist;

import java.util.Collections;
import java.util.List;

public class Mainemployelinklist {
    Node head;

    class Node {
        Object data;

        Node next;

        Node(Object d) {
            data = d;
            next = null;
        }
    }
        public  void insert(Object data)
        {
            Node newNode = new Node(data);

            if(head==null)
            {
                head=newNode;

                newNode.next=null;

            }
            else
            {
                Node last;
                last=head;
                while(last.next!=null)
                {
                    last=last.next;

                }
                last.next=newNode;
            }
        }
    public void insertfirst(Object data)

    {
        Node newNode = new Node(data);
        if(head==null)
        {
            head=newNode;

            newNode.next=null;

        }
        else
        {
            Node temp=head;
            head=newNode;
            head.next=temp;
        }
    }
    public void remove(Object data)

    {
        Node q = new Node(data);
        Node currNode = head, prev = null;
        if(currNode==null)//removing if link is empty
        {
            System.out.println("yor Linklist is empty");
        }

       else if (head.data.equals(q.data)) {//removing first node
            currNode = currNode.next;
            head = currNode;
        }
        else {

            while (!(currNode .equals(null ))&& !currNode.data .equals(data)) {//removing data
                prev = currNode;
                currNode = currNode.next;

            }
            if (currNode.data .equals(q.data))
            prev.next = currNode.next;
        }

    }
    boolean removeindex(int index)
    {
        boolean flag=false;
        int c = 0;
        Node currNode = head, prev = null;
        if(index==0)
        {
            head=head.next;
            flag=true;
            return flag;

        }
        while (currNode != null) {

            if (c == index) {
                prev.next = currNode.next;
                flag=true;
                break;
            }
            else
            {
                prev=currNode;
                currNode=currNode.next;
                c++;
            }

        }
        if(c!=index)

            System.out.println("not any position found");



        return flag;


    }
    public void addobjectafter(Object news,Object prev)
    {
        Node newNode = new Node(news);
        Node currNode;
        Node pre=null;
        currNode=head;
        while (!(currNode .equals(null ))&& !(currNode.data ).equals(prev)) {
            pre = currNode;
            currNode = currNode.next;


        }
        if (currNode.data .equals(prev)) {
            newNode.next = currNode.next;
            currNode.next = newNode;
        }

    }
    public void addobjectafterindex(Object news,int index) {
        Node newNode = new Node(news);
        Node currNode;
        Node pre = null;
        currNode = head;
        int c = 0;
        while (currNode != null) {

            if (c == index) {
                newNode.next = currNode.next;
                currNode.next = newNode;

                break;
            }
            else {
                pre=currNode;
                currNode=currNode.next;
                c++;

            }
        }
    }
        public void print ()
        {

            Node currNode = head;

            System.out.print("LinkedList: ");

            // Traverse through the LinkedList
            while (currNode != null) {
                // Print the data at current node
                System.out.print(currNode.data + " ");

                // Go to next node
                currNode = currNode.next;
            }
            System.out.println();

        }
        public int search(Object o) {
            int c = 0;
            Node newNode = new Node(o);
            Node currNode;
            currNode = head;
            while (currNode != null) {
                if ((currNode.data).equals(o)) {
                    return c;

                } else {
                    currNode = currNode.next;
                    c++;
                }


            }return c;
        }


    public static void main(String[] args) {
        Mainemployelinklist list=new Mainemployelinklist();
        EmployeeLinklist emp=new EmployeeLinklist(10000,12,"mayank");
        list.insert(emp);
        EmployeeLinklist emp1=new EmployeeLinklist(30000,23,"aman");
        list.insert(emp1);
        EmployeeLinklist emp3=new EmployeeLinklist(30040,23,"naman");
        list.insert(emp3);
        EmployeeLinklist emp4=new EmployeeLinklist(40000,23,"rishabh");
        list.insert(emp4);
       list.print();
        list.toString();
        EmployeeLinklist emp5=new EmployeeLinklist(9000,23,"aman");
        list.insertfirst(emp5);
       list.remove(emp4);
        list.print();
        list.toString();
      boolean flag=  list.removeindex(0);
        System.out.println(flag);
        list.print();
        list.toString();
        EmployeeLinklist emp6=new EmployeeLinklist(9000,23,"avishek");
        list.addobjectafter(emp6,emp3);
        list.print();
        list.toString();
        EmployeeLinklist emp7=new EmployeeLinklist(10000,23,"manku");
        list.addobjectafterindex(emp7,3);
        list.print();
        list.toString();

       int k= list.search(emp6);
       System.out.println("the position of object is"+k);





    }


}
