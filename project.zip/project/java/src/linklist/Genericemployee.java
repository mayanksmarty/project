package linklist;

public class Genericemployee<T> {
    Node<T> head;
    class Node<T> {
        T data;

        Node<T> next;

        public Node(T d) {
            T data = d;
            T next = null;
        }
    }
        public  void insert(T data)
        {
            Node<T> newNode = new Node(data);

            if(head==null)
            {
               T head= (T) newNode;

                newNode.next=null;

            }
            else
            {
                Node<T> last;
                last = head;
                while(last.next!=null)
                {
                    last=last.next;

                }
                last.next=newNode;
            }
        }
    public void insertfirst(T data)

    {
        Node <T>newNode = new Node(data);
        if(head==null)
        {
            head=newNode;

            newNode.next=null;

        }
        else
        {
            Node<T> temp=head;
            head=newNode;
            head.next=temp;
        }
    }
    public void remove(T data)

    {
        Node<T> q = new Node(data);
        Node <T>currNode = head, prev = null;
        if(currNode==null)//removing if link is empty
        {
            System.out.println("yor Linklist is empty");
        }

        else if (head.data.equals(q.data)) {//removing first node
            currNode = currNode.next;
            head = currNode;
        }
        else {

            while (!(currNode .equals(null ))&& !currNode.data .equals(data)) {//removing data
                prev = currNode;
                currNode = currNode.next;

            }
            if (currNode.data .equals(q.data))
                prev.next = currNode.next;
        }

    }
    boolean removeindex(int index)
    {
        boolean flag=false;
        int c = 0;
        Node<T> currNode = head, prev = null;
        while (currNode != null) {

            if (c == index) {
                prev.next = currNode.next;
                flag=true;
                break;
            }
            else
            {
                prev=currNode;
                currNode=currNode.next;
                c++;
            }

        }
        if(c!=index)

            System.out.println("not any position found");



        return flag;


    }
    public void addobjectafter(T news,T prev)
    {
        Node<T> newNode = new Node(news);
        Node<T> currNode;
        Node<T> pre=null;
        currNode=head;
        while (!(currNode .equals(null ))&& !(currNode.data ).equals(prev)) {
            pre = currNode;
            currNode = currNode.next;


        }
        if (currNode.data .equals(prev)) {
            newNode.next = currNode.next;//we have not use pre as it is not working
            currNode.next = newNode;
        }

    }
    public void addobjectafterindex(T news,int index) {
        Node newNode = new Node(news);
        Node<T> currNode;
        Node <T>pre = null;
        currNode = head;
        int c = 0;
        while (currNode != null) {

            if (c == index) {
                newNode.next = currNode.next;
                currNode.next = newNode;

                break;
            }
            else {
                pre=currNode;
                currNode=currNode.next;
                c++;

            }
        }
    }
    public void print ()
    {

        Node<T> currNode = head;

        System.out.print("LinkedList: ");

        // Traverse through the LinkedList
        while (currNode != null) {
            // Print the data at current node
            System.out.print(currNode.data + " ");

            // Go to next node
            currNode = currNode.next;
        }
        System.out.println();

    }
    public int search(T o) {
        int c = 0;
        Node <T>newNode = new Node(o);
        Node <T>currNode;
        currNode = head;
        while (currNode != null) {
            if ((currNode.data).equals(o)) {
                return c;

            } else {
                currNode = currNode.next;
                c++;
            }


        }return c;
    }
    public static void main(String[] args) {
        Mainemployelinklist list = new Mainemployelinklist();
        EmployeeLinklist emp = new EmployeeLinklist(10000, 12, "mayank");
        list.insert(emp);
        EmployeeLinklist emp1 = new EmployeeLinklist(30000, 23, "aman");
        list.insert(emp1);
        EmployeeLinklist emp3 = new EmployeeLinklist(30040, 23, "naman");
        list.insert(emp3);
        EmployeeLinklist emp4 = new EmployeeLinklist(40000, 23, "rishabh");
        list.insert(emp4);
        list.print();
        list.toString();
        EmployeeLinklist emp5 = new EmployeeLinklist(9000, 23, "aman");
        list.insertfirst(emp5);
        list.remove(emp4);
        list.print();
        list.toString();
        boolean flag = list.removeindex(3);
        System.out.println(flag);
        list.print();
        list.toString();
        EmployeeLinklist emp6 = new EmployeeLinklist(9000, 23, "avishek");
        list.addobjectafter(emp6, emp5);
        list.print();
        list.toString();
        EmployeeLinklist emp7 = new EmployeeLinklist(10000, 23, "manku");
        list.addobjectafterindex(emp7, 3);
        list.print();
        list.toString();
        int k = list.search(emp6);
        System.out.println("the position of object is at " + k);
    }





    }



