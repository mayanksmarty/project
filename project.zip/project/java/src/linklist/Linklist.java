package linklist;

public class Linklist {

    Node head;

    class Node{
int data;

Node next;
        Node(int d)
        {
            this.data = d;
            this.next = null;
        }
    }
    public  void insert(int data)
    {
    Node newNode = new Node(data);

        if(head==null)
        {
            head=newNode;

            newNode.next=null;

        }
        else
        {
            Node last;
            last=head;
            while(last.next!=null)
            {
                last=last.next;

            }
            last.next=newNode;
        }
    }
    public void insertfirst(int data)

    {
        Node newNode = new Node(data);
        if(head==null)
        {
            head=newNode;

            newNode.next=null;

        }
        else
        {
            Node temp=head;
            head=newNode;
            head.next=temp;
        }
    }
    public void remove(int data) {
        Node q = new Node(data);
       Node currNode = head;Node prev = null;
        if (head== null) {
            System.out.println("yor Linklist is already deleted");

        } else {
           if (currNode.data == q.data) {//removing first node
                currNode = currNode.next;
                head = currNode;

            } else {
                while (currNode.next != null && currNode.data != q.data) {//removing data
                    prev = currNode;
                    currNode = currNode.next;

                }
               if (currNode.data == q.data)
                prev.next = currNode.next;
            }
           if(currNode==null)
           {
               System.out.println("Linklist cant be deleted");
           }
        }
    }
    public void removeposition(int index) {
        int c = 0;
        Node currNode = head, prev = null;
        while (currNode != null) {

            if (c == index) {
                prev.next = currNode.next;
                break;
            }
            else
            {
                prev=currNode;
                currNode=currNode.next;
                c++;
            }

        }
        System.out.println("not any position found");
    }
    public void print() {
        Node currNode = head;

        System.out.print("LinkedList: ");
        if(currNode==null)
        {
            System.out.println("your linklist is empty");
        }
        else {

            // Traverse through the LinkedList
            while (currNode != null) {
                // Print the data at current node
                System.out.print(currNode.data + " ");

                // Go to next node
                currNode = currNode.next;
            }
        }
    }

    public static void main(String[] args) {
        Linklist l=new Linklist();
     l.insert(1);
     l.insert(2);
     l.insert(3);
     l.insert(4);
     l.insert(5);
     l.insert(6);
     l.insert(7);

     l.print();

     l.remove(2);
     l.remove(4);
     l.remove(6);

     l.print();
     l.insertfirst(9);
     l.print();

       l.remove(6);
       l.print();
       l.remove(1);
       l.remove(3);
       l.remove(5);
       l.remove(7);
       l.print();
       l.remove(4);
    }
}
