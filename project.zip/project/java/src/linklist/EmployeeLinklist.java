package linklist;

import java.util.Objects;

public class EmployeeLinklist implements Comparable<EmployeeLinklist> {
    private double sal;
    private  int age;
    private String name;
    public double getSal() {
        return sal;
    }



    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }
    public EmployeeLinklist (double sal, int age, String name) {
        this.sal = sal;
        this.age = age;
        this.name=name;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeLinklist that = (EmployeeLinklist) o;
        return Double.compare(that.sal, sal) == 0 &&
                age == that.age &&
                Objects.equals(name, that.name);
    }


    public String toString() {
        return "EmployeeLinklist{" +
                "sal=" + sal +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }

    @Override
    public int compareTo(EmployeeLinklist o) {
        if(this.age>o.age)
            return 1;
        else if(this.age<o.age)
            return -1;
        else return 0;

    }
}
