package loan;

import java.time.LocalDate;

public class Customer {
    private int customerId;
    private  String customerName;
    private LocalDate dateOfBirth;
    private String contactno;
    private  String emailAddress;
    private   String profession;
    private  double totalMonthlyExpense;
    private   String designation;
    private  String companyName;
    private double monthlyIncome;
    private static int count=0;

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
//
    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public Customer() {
        this.customerId = ++count;
    }

    public String getContactno() {
        return contactno;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getProfession() {
        return profession;
    }

    public double getTotalMonthlyExpense() {
        return totalMonthlyExpense;
    }

    public String getDesignation() {
        return designation;
    }

    public String getCompanyName() {
        return companyName;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }


    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public void setTotalMonthlyExpense(double totalMonthlyExpense) {
        this.totalMonthlyExpense = totalMonthlyExpense;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", customerName='" + customerName + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", contactno='" + contactno + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", profession='" + profession + '\'' +
                ", totalMonthlyExpense=" + totalMonthlyExpense +
                ", designation='" + designation + '\'' +
                ", companyName='" + companyName + '\'' +
                ", monthlyIncome=" + monthlyIncome +
                '}';
    }

    public double dbr()
    {
       double dbr=getTotalMonthlyExpense()/getMonthlyIncome();

        System.out.println("DBR will be"+dbr);
        return dbr;
    }
    public double maximumeligibleemi()
    {
        double expenses = ( getMonthlyIncome()-getTotalMonthlyExpense()) / 2;
        double emi=expenses-(getMonthlyIncome()*0.20);
        return emi;
    }
}
