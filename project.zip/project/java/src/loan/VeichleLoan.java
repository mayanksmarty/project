package loan;

import java.time.LocalDate;

public class VeichleLoan extends SecuredLoan {


    public VeichleLoan(laonstatus s) {
        super(s);
    }



    private String vehicleCategory;
    private String vehicleModelNo;
    private String manufacture;
    private int yearOfManufacture;
    private double assetValue;

    public String getVehicleCategory() {
        return vehicleCategory;
    }

    public void setVehicleCategory(String vehicleCategory) {
        this.vehicleCategory = vehicleCategory;
    }

    public String getVehicleModelNo() {
        return vehicleModelNo;
    }

    public void setVehicleModelNo(String vehicleModelNo) {
        this.vehicleModelNo = vehicleModelNo;
    }

    public String getManufacture() {
        return manufacture;
    }

    public void setManufacture(String manufacture) {
        this.manufacture = manufacture;
    }

    public int getYearOfManufacture() {
        return yearOfManufacture;
    }

    public void setYearOfManufacture(int yearOfManufacture) {
        this.yearOfManufacture = yearOfManufacture;
    }

    public double getAssetValue() {
        return assetValue;
    }

    public void setAssetValue(double assetValue) {
        this.assetValue = assetValue;
    }
    @Override
    public double calcloantovalue() {
        double v = getLoanAmount()/getAssetValue();
        return v;
    }
}
