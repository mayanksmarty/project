package loan;

import java.util.Scanner;

public class Exceptions {

    double g;
    double k;
    double r;
    double t,a;

   public void calcloanamount()  throws LoannotApprovedException{
        double expenses = (g / k) ;
        double emi =(((k-g)/2 -k * 0.20));
        System.out.println("emi"+emi);

       double Maximumemi = (emi *( Math.pow((1 + r),t) -1 ))/ (r*Math.pow((1 + r), t));
       System.out.println("maximum eligible loan amount will be " + Maximumemi);
       if(a>Maximumemi)
       {
           throw new LoannotApprovedException("the loan is not approved");
       }


    }
    public void calloantovalue(String loantype) throws LoannotApprovedException
    {

       if(loantype.equalsIgnoreCase("homeloan")) {
           HomeLoan h = new HomeLoan(CustomerLoan.laonstatus.Pending);
           double m = h.calcloantovalue();
           if (m > .80 || t>=60) {
               throw new LoannotApprovedException("the loan is not approved");
           }
           else
           {
               System.out.println("Loan is Approved");
           }
       }
       else if(loantype.equalsIgnoreCase("vehicalloan"))
        {
        VeichleLoan v=new VeichleLoan(CustomerLoan.laonstatus.Pending);
       double m1=v.calcloantovalue();
       if(m1>.80)
       {
           throw new LoannotApprovedException("the loan is not approved");
       }
       else if(loantype.equalsIgnoreCase("Personallaon"))
       {
           PersonalLoan pl=new PersonalLoan(CustomerLoan.laonstatus.Pending);
           double experience=pl.getWorkExperience();
           if(k>500000 || experience>5)
           {
               System.out.println("Loan is Approved");
           }
           else
           {
               throw new LoannotApprovedException("the loan is not approved");
           }
       }

    }
    }


    public static void main(String args[]) throws LoannotApprovedException {
        Scanner sc=new Scanner(System.in);
        HomeLoan h=new HomeLoan(CustomerLoan.laonstatus.Pending );
        Exceptions el=new Exceptions();
        System.out.println("enter Loan Amount");
        h.setLoanAmount(sc.nextDouble());
        el.a=h.getLoanAmount();
        System.out.println("enter the tenure");
        h.setTenure(sc.nextInt());
        el.t=h.getTenure();
        System.out.println("enter the roi");
        h.setRoi(sc.nextDouble());
        el.r=h.getRoi();
        System.out.println("enter monthly expanse");
        h.setmonthlyExpanse(sc.nextDouble());
          el.g=h.getmonthlyExpanse();

        System.out.println("enter monthlyincome");
        h.setmonthlyIncome(sc.nextDouble());
        el.k=h.getmonthlyIncome();

        try {
            el.calcloanamount();

        }
        catch(LoannotApprovedException e)
        {
            System.out.println();
        }
        System.out.println("enter the proprerty value");
        h.setPropertyValue(sc.nextDouble());
        System.out.println("enter loan type");
        h.setLoanType(sc.next());
        String loantype=h.getLoanType();


        PersonalLoan pl=new PersonalLoan(CustomerLoan.laonstatus.Pending);
        System.out.println("enter The Experience");
        pl.setWorkExperience(sc.nextInt());
        try {
            el.calloantovalue(loantype);

        }
        catch(LoannotApprovedException e)
        {
            System.out.println();
        }

        double dbr=el.g/el.k;
        System.out.println(" the debris value for approval of loan is"+dbr);
        if(dbr>.40)
        {
            throw new LoannotApprovedException("Loan not Approved");
        }











    }



}
