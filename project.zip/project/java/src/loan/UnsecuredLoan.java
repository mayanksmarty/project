package loan;

public  abstract class UnsecuredLoan extends CustomerLoan {


    public UnsecuredLoan(laonstatus s) {
       // super(s);
    }
}
