package loan;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public  abstract class CustomerLoan {

    private String LoanType;
    private int LoanId;
    private double loanAmount;
    private int tenure;
    private double roi;

    private double monthlyIncome;
    private double monthlyExpanse;
    private static int count = 0;

    enum laonstatus {
        Approved, Rejected, Pending,Closed;
    }

    private double emiperMonth;
    private LocalDate loanDisbursalDate;
    private double maximumEmi;
    private int day;
    private int month;
    private int year;
    ArrayList<Emi>list= new ArrayList<Emi>();

    public ArrayList<Emi> getList() {
        return list;
    }

    public void setList(ArrayList<Emi> list) {
        this.list = list;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }



    laonstatus status;

    public LocalDate getPaymentdate() {
        return paymentdate;
    }

    public void setPaymentdate(LocalDate paymentdate) {
        this.paymentdate = paymentdate;
    }

    private LocalDate paymentdate;


    public double getmonthlyIncome() {
        return monthlyIncome;
    }

    public void setmonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public double getmonthlyExpanse() {
        return monthlyExpanse;
    }

    public void setmonthlyExpanse(double monthlyExpanse) {
        this.monthlyExpanse = monthlyExpanse;
    }


    public int getLoanId() {
        return LoanId;
    }

    private int repaymentfrequency;


    public void setLoanType(String loanType) {
        LoanType = loanType;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public void setRoi(double roi) {
        this.roi = roi;
    }

    public void setEmiperMonth(double emiperMonth) {
        this.emiperMonth = emiperMonth;
    }

    public void setloanDisbursalDate(LocalDate loanDisbursalDate) {
        this.loanDisbursalDate = loanDisbursalDate;
    }

    public void setMaximumEmi(double maximumEmi) {
        this.maximumEmi = maximumEmi;
    }

    public String getLoanType() {
        return LoanType;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public int getTenure() {
        return tenure;
    }

    public double getRoi() {
        return roi;
    }

    public double getEmiperMonth() {
        return emiperMonth;
    }

    public LocalDate getloanDisbursalDate() {
        return loanDisbursalDate;
    }

    public double getMaximumEmi() {
        return maximumEmi;
    }

    public int getRepaymentfrequency() {
        return repaymentfrequency;
    }


    public void setRepaymentfrequency(int repaymentfrequency) {
        this.repaymentfrequency = repaymentfrequency;
    }

    public laonstatus getStatus() {
        return status;
    }

    public void setStatus(laonstatus status) {
        this.status = status;
    }

//laonstatus status;

    public CustomerLoan() {

        this.LoanId = ++count;
    }

    @Override
    public String toString() {
        return "Customerloan{" +
                "LoanType='" + LoanType + '\'' +
                ", LoanId=" + LoanId +
                ", loanAmount=" + loanAmount +
                ", tenure=" + tenure +
                ", roi=" + roi +
                ", monthlyIncome=" + monthlyIncome +
                ", monthlyExpanse=" + monthlyExpanse +
                ",  loanDisbursalDate=" + loanDisbursalDate +
                ", paymentdate=" + paymentdate +
                ", repaymentfrequency=" + repaymentfrequency +
                ", status=" + status +
                '}';
    }



    double calcemi() {

        double loanamount = getLoanAmount();

        double rate=getRoi()/(getRepaymentfrequency()*100);
        double b=1+rate;
        int tenure=12*getTenure();

        double installmentAmount =((loanamount*rate)/(1-(1/Math.pow(b,tenure))));
        return installmentAmount;

    }

    double calcloanamount() {
        double emi=((getmonthlyIncome()-getmonthlyExpanse())/2) - (getmonthlyIncome()* 0.20);

        double rate=getRoi()/1200;
       int tenure=12*getTenure();

        double Maximumemi = (emi * (Math.pow((1 + rate), tenure)-1)) /(rate* (Math.pow((1 + rate), tenure)));
        return Maximumemi;
    }

    void repymentschedule() {
        int residualvalue = 0;
        double interest;
        double principle;
        double loanamount = getLoanAmount();

        double rate=getRoi()/(getRepaymentfrequency()*100);
        double b=1+rate;
        int tenure=12*getTenure();

        double installmentAmount =((getLoanAmount()*rate)/(1-(1/Math.pow(b,tenure))));
        System.out.println("installment amount is " + installmentAmount);
        for (int installmentno = 1; installmentno <= tenure; installmentno++) {
            interest = (loanamount * getRoi())/1200;
            Emi emi = new Emi();
            principle = installmentAmount - interest;
            loanamount = loanamount - principle;

            emi.setInterestAmount(interest);
            emi.setPrincipleComponent(principle);
            list.add(emi);
            System.out.println("the installment for "+ " " + installmentno + " " + " year with insterst and principle"+ " " + interest + " " + " and " + " " + principle + " " + " and their installment(op)" + loanamount);

        }
    }

    void calcpenalty(double emi) {
        Scanner sc = new Scanner(System.in);
        LocalDate ld = getloanDisbursalDate();

        double r = getLoanAmount();
        for (long i = 1; i <= getTenure(); i++) {
            LocalDate duedate = ld.plusMonths(i);
            System.out.println(duedate);
            System.out.print("is emi is paid or not:-");
            String a = sc.nextLine();
            if (a.equals("yes") || a.equals("yes") || a.equals("YES") || a.equals("Y")) {
                double interest = r * (getRoi() / 12);
                double principle = emi - interest;
                r = r - principle;
            } else {

                System.out.println("Enter the payment date");
                setDay(sc.nextInt());
                System.out.println("Enter the payment month");
                setMonth(sc.nextInt());
                System.out.println("Enter the payment year");
                setYear(sc.nextInt());
                sc.nextLine();//for the next entry with the int and string
                LocalDate ld1 = LocalDate.of(getYear(), getMonth(), getDay());
                setPaymentdate(ld1);
                int l = duedate.getYear();
                int l3 = duedate.getMonthValue();
                int l4 = duedate.getDayOfMonth();
                int l5 = getPaymentdate().getYear();
                int l6 = getPaymentdate().getMonthValue();
                int l7 = getPaymentdate().getDayOfMonth();
                int q = l5 - l;
                int w = l6 - l3;
                int e = l7 - l4;

                double k = q * 360 + Math.abs(w) * 30 + Math.abs(e);
                double interest = emi * (k / 30);
                System.out.println(interest);
                i = i + w;


            }

        }
    }
}
