package loan;


import java.io.IOException;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.stream.Stream;

public class Bank  implements Maker,Checker{
    CustomerLoan[] cust = new CustomerLoan[100];
    TreeMap<Integer,Customer> hm=new TreeMap<Integer,Customer>();
    Customer c[]=new Customer[100];
    Emi emi = new Emi();

    int q = 0;

    CustomerLoan ln;
    private static Bank instance = null;
    private Bank() { }
    public static Bank getInstance() {
        if (instance == null) {
            instance = new Bank();
        }
        return instance;
    }
    public boolean registerCustomer(Customer c)
    {
      hm.put(c.getCustomerId(),c);
      return true;
    }
    public Customer findCustomer ( int CustomerID)
    {

        return hm.get(CustomerID);
    }


    public  int applylaon(double LoanAmount, Double roi, int tenure, String typeoflaoan, int repaymentfrequency) {
        if (typeoflaoan.equalsIgnoreCase("Homeloan") || typeoflaoan.equalsIgnoreCase("Homeloan")) {
            cust[q] = new HomeLoan(CustomerLoan.laonstatus.Pending);
        }
        else if (typeoflaoan.equalsIgnoreCase("Veichle loan") || typeoflaoan.equalsIgnoreCase("Veichleloan"))
        { cust[q] = new VeichleLoan(CustomerLoan.laonstatus.Pending);}
        else if (typeoflaoan.equalsIgnoreCase("Personal loan") || typeoflaoan.equalsIgnoreCase("PersonalLoan"))
      {
          cust[q] = new PersonalLoan(CustomerLoan.laonstatus.Pending);}
            cust[q].setLoanAmount(LoanAmount);
           cust[q].setRoi(roi);
      cust[q].setTenure(tenure);
      cust[q].setRepaymentfrequency(repaymentfrequency);
      cust[q].setStatus(CustomerLoan.laonstatus.Pending);
      cust[q].setLoanType(typeoflaoan);
            System.out.println(cust[q]+","+q);
            int loanId=cust[q].getLoanId();
            System.out.println("Application id is "+loanId);
            q++;

            return loanId;
  }
       public  String trackloanstatus ( int loanApplicationId)

        {
            String p=null;
            //for (int i = 0; i < q; i++)
            for(CustomerLoan ln1 : cust) {

                if (loanApplicationId == ln1.getLoanId()) {
                   // System.out.println(ln1.getStatus());
                    p = ln1.getStatus().toString();
                    return p;
                }
                break;
            }
                return p;
        }
      public  void approverejectloan(int loanAppliocationId,double monthlyIncome,double monthlyExpanse) {

          cust[q].setmonthlyIncome(monthlyIncome);
          cust[q].setmonthlyExpanse(monthlyExpanse);


          for (int i = 0; i < q; i++) {
              if (loanAppliocationId == cust[i].getLoanId()) {
                  if (cust[i].getLoanAmount() < cust[i].calcloanamount()) {
                      cust[i].setStatus(CustomerLoan.laonstatus.Approved);
                      System.out.println(cust[i].getStatus());
                  } else {
                      try {
                          cust[i].setStatus(CustomerLoan.laonstatus.Rejected);
                          throw new LoannotApprovedException("pls enter again");

                      } catch (Exception e) {
                          System.out.println(e);
                      }
                  }
                  if (cust[i].getLoanType().equalsIgnoreCase("veichleloan")) {
                      VeichleLoan loans = (VeichleLoan) cust[i];
                      if (loans.calcloantovalue() < .80) {
                          cust[i].setStatus(CustomerLoan.laonstatus.Rejected);
                      }
                  }
                  if (cust[i].getLoanType().equalsIgnoreCase("homeloan")) {
                      LocalDate today = LocalDate.now();                          //Today's date
                      LocalDate birthday = (c[i].getDateOfBirth());  //Birth date

                      Period p = Period.between(birthday, today);
                      int years =p.getMonths();
                      LocalDate ld =cust[i]. getloanDisbursalDate();
                      int l = ld.getYear();

                      HomeLoan loans = (HomeLoan) cust[i];
                      if (loans.calcloantovalue() < .80 && (loans.getTenure()+years)>60) {
                          try {
                              cust[i].setStatus(CustomerLoan.laonstatus.Rejected);
                              throw new LoannotApprovedException("pls enter again");
                          }
                          catch (Exception e)
                          {
                              System.out.println(e);
                          }
                         
                      }
                  }
                  if (cust[i].getLoanType().equalsIgnoreCase("personalaloan")) {
                      PersonalLoan loans = (PersonalLoan) cust[i];
                      if (loans.getmonthlyIncome() * 12 > 500000 && loans.getWorkExperience() > 5) {
                          cust[i].setStatus(CustomerLoan.laonstatus.Rejected);
                      }


                  }
              }
          }
      }
    public void payEMI(int loanAccountNumber, double emiAmount, int month) {
        for(CustomerLoan ln: cust) {
            if (ln.getLoanId() == loanAccountNumber) {

                /*Emi emi = ln.getList().get(month - 1);

                double pendingEmiAmount = emi.getEmiAmount() + emi.getPenaltyCharges();
emi.setStatus("pending");
                if (emi.getStatus().equals("pending") && emiAmount == pendingEmiAmount) {
                    emi.setStatus("PAID");
                    emi.setEmiAmount(emiAmount);
                }*/


                if(emiAmount == emi.getEmiAmount())
                    emi.setStatus("Paid");
                else if(emi.getEmiAmount() < emiAmount) {
                    double pendingEmiAmount = (emi.getEmiAmount() - emiAmount) + emi.getPenaltyCharges();
                    emi.setPenaltyCharges(pendingEmiAmount);
                }
                else
                    emi.setStatus("Pending");
            }
        }
    }
    /*public void endOfDayProcess() {
        for (CustomerLoan loan: cust) {
            ArrayList<Emi> emiList = loan.getList();
            boolean duesSettled = true;
            LocalDate maturityDate = emiList.get(emiList.size() - 1).getEmiDueDate();

            double latePenalty = loan.calcpenalty();

            if (LocalDate.now().compareTo(maturityDate) == 0 && latePenalty == 0) {
                loan.setStatusOfLoan(LoanStatus.CLOSED);
            }
        }
    }*/
    /*void writeIntoFile(CustomerLoan loan)  {
        ObjectOutputStream objectOutputStream = Stream.get();
        try {
            if (loan instanceof HomeLoan) {
                HomeLoan homeLoan = (HomeLoan) loan;
                objectOutputStream.writeObject(homeLoan);
            }
            if (loan instanceof PersonalLoan) {
                PersonalLoan personalLoan = (PersonalLoan) loan;
                objectOutputStream.writeObject(personalLoan);
            }
            if (loan instanceof VeichleLoan) {
                VeichleLoan vehicleLoan = (VeichleLoan) loan;
                objectOutputStream.writeObject(vehicleLoan);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
*/

      public void loanDisbursal(int loanId)
      {
          for(CustomerLoan ln: cust)
          {
              if(ln.getLoanId() == loanId)
              {
                  if(ln.getStatus().equals(CustomerLoan.laonstatus.Approved))
                  {
                      ln.setStatus(CustomerLoan.laonstatus.Approved);
                      ln.setloanDisbursalDate(LocalDate.now());
                      ln.calcemi();
                      emi.setEmiAmount(ln.calcemi());
                  }
              }
          }
      }


     public   void getallactiveloandetail()
        {
            for(int i=0;i<q;i++)
            {
                System.out.println(cust[i].toString());
            }
        }
    public    void getLoandetails(int loanAccountno)
        {
            for (CustomerLoan ln1 : cust) {
                if(loanAccountno==ln1.getLoanId())
                System.out.println(ln1);
                break;
            }

            }

     public   boolean removeloanAccount(int loanaccountno)
        { boolean flag=false;
            for (CustomerLoan ln1 : cust)

            {
                if(loanaccountno==ln1.getLoanId())
                {
         if(ln1.getStatus().equals(CustomerLoan.laonstatus.Closed)||ln1.getStatus().equals(CustomerLoan.laonstatus.Rejected))
                    {

                        /*for(int j = i; j< q; j++){
                            cust[i] = cust[i + 1];
                            flag=true;*/
                        flag=true;
                        break;
                        }

                    }


                }return flag;


        }


        }


