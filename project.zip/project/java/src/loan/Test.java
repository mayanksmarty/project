package loan;

import com.sun.deploy.security.SelectableSecurityManager;

import javax.swing.plaf.synth.SynthTextAreaUI;
import java.time.LocalDate;
import java.util.Scanner;

public class Test {
    public static void main(String args[]) {

        String loanType;
        Double loanAmount;
        int tenure, day, month, year;
        double roi;
        int repaymentFrequency;
        double monthlyIncome;
        double monthlyExpanse;
        int loanApplicationId;

        Test l1 = new Test();
        CustomerLoan l;

        BankFactory b = new BankFactory();
        Maker m = b.getBank();

        Scanner sc = new Scanner(System.in);
        System.out.println("are you checker or maker");
        String s = sc.next();
        if (s.equalsIgnoreCase("maker")) {
            Creation.makecustomer();
            System.out.println("enter the customer_id to check the details");
            int c2 = sc.nextInt();
            Customer f = m.findCustomer(c2);
            while (f == null) {
                System.out.println("not any CustometID found");
                Creation.makecustomer();
                int c3 = sc.nextInt();
                Customer x = m.findCustomer(c2);
                f=x;
            }
            System.out.println("ID is true NOW Enter FOR APPLY LOan ANd MAny THING");
            int j = 1;
            do {

                System.out.println("Enter 1 for apply Loan ");
                System.out.println("Enter 2 for track Loan status");
                System.out.println("Enter 3 for  Loan Details ");
                System.out.println("Enter 4 for get all ActiveLoan Details");
                System.out.println("Enter  5 for LonDisbursal");
                System.out.println("enter 6 to pay Emi");
                System.out.println("enter 7to leave from here");

                int k = sc.nextInt();
                switch (k) {
                    case 1:

                        System.out.println("enter the type of loan \n home loan \n veichle loan \n personal loan");
                        loanType = sc.next();

                        System.out.println("enter Loan Amount");
                        loanAmount = sc.nextDouble();

                        System.out.println("enter the tenure");
                        tenure = sc.nextInt();

                        System.out.println("enter the roi");
                        roi = sc.nextDouble();

                        System.out.println("enter repayment frequency");
                        repaymentFrequency = sc.nextInt();
                        System.out.println("enter monthly expanse");
                        monthlyExpanse = sc.nextDouble();
                        System.out.println("enter monthlyincome");
                        monthlyIncome = sc.nextDouble();
                        System.out.println("enter day");
                        day = sc.nextInt();
                        System.out.println("enter month");
                        month = sc.nextInt();
                        System.out.println("enter year");
                        year = sc.nextInt();

                        if (loanType.equalsIgnoreCase("Homeloan") || loanType.equalsIgnoreCase("Home Loan")) {
                          HomeLoan  hl = new HomeLoan(CustomerLoan.laonstatus.Pending);
                            System.out.println("Enter the builder name");
                            ((HomeLoan) hl).setBuilderName(sc.nextLine());
                            System.out.println("enter property size");
                            ((HomeLoan) hl) .setPropertySize(sc.nextInt());
                            System.out.println("enter property value");
                            ((HomeLoan)hl).setPropertyValue(sc.nextDouble());


                        } else if (loanType.equalsIgnoreCase("veichleloan") || loanType.equalsIgnoreCase("veichle Loan")) {
                         VeichleLoan   vl = new VeichleLoan(CustomerLoan.laonstatus.Pending);
                            System.out.println("Enter the Veichle Category");
                            ((VeichleLoan) vl).setVehicleCategory(sc.nextLine());
                            System.out.println("enter veichle model no.");
                            ((VeichleLoan) vl).setVehicleModelNo(sc.nextLine());
                            System.out.println("Enter the manufacture");
                            ((VeichleLoan) vl).setManufacture(sc.nextLine());
                            System.out.println("Enter the yearOfManufacture");
                            ((VeichleLoan) vl).setYearOfManufacture(sc.nextInt());
                            System.out.println("Enter the asset value");
                            ((VeichleLoan) vl).setAssetValue(sc.nextDouble());
                        } else {
                             PersonalLoan pl = new PersonalLoan(CustomerLoan.laonstatus.Pending);
                            System.out.println("Enter the Qualifiaction");
                            sc.nextLine();
                            ((PersonalLoan) pl).setQualifiacation(sc.nextLine());
                            System.out.println("enter work Experience");
                            ((PersonalLoan) pl) .setWorkExperience(sc.nextDouble());
                        }
                       /* LocalDate ld = LocalDate.of(l.getYear(), l.getMonth(), l.getDay());
                        System.out.println("the disbursal date will be" + ld);

                        l.setloanDisbursalDate(ld);*/
                        m.applylaon(loanAmount, roi, tenure, loanType, repaymentFrequency);
                        break;
                    case 2:
                        System.out.println("pls enter the loan id");
                        int loanID = sc.nextInt();
                        String b2 = m.trackloanstatus(loanID);
                        System.out.println(b2);
                        break;
                    case 3:
                        System.out.println("pls enter the loan id");
                        int ld1 = sc.nextInt();
                        m.getLoandetails(ld1);
                        break;
                    case 4:
                        m.getallactiveloandetail();
                        break;
                    case 5:
                        System.out.println("pls enter the loan id");
                        int ld6= sc.nextInt();
                        m.loanDisbursal(ld6);
                    case 6:
                        System.out.println("pls enter the loan id");
                        int ld3= sc.nextInt();
                        Emi e=new Emi();
                        System.out.println("enter the Emi Amount");
                        Double EmiAmount=sc.nextDouble();
                        System.out.println("enter the month");
                        int mont=sc.nextInt();
                     ;  m.payEMI(ld3, EmiAmount,mont);
                    case 7:
                        j=7;
                        break;
                }


            } while (j < 6);//if closes

        }

            System.out.println("enter for the checker");
            Checker c = b.getBank();

            int k = sc.nextInt();
            switch (k) {
                case 1:
                    System.out.println("make to apply reject and remove loans");
                    int loanId = sc.nextInt();
                    System.out.println("enter monthly expanse");
                    monthlyExpanse = sc.nextDouble();
                    System.out.println("enter monthlyincome");
                    monthlyIncome = sc.nextDouble();
                    c.approverejectloan(loanId, monthlyIncome, monthlyExpanse);

                case 2:
                    System.out.println("enter to remove loan");
                    int loanid2 = sc.nextInt();
                    c.removeloanAccount(loanid2);
                    break;
                case 3:
                    System.out.println("enter to LoanDisbursalId");
                    int j = sc.nextInt();
                    c.loanDisbursal(j);
                    break;




            }




            /*System.out.println("loan id " + h.getLoanId());*/

               /*  if (loanType.equalsIgnoreCase("Homeloan") || loanType.equalsIgnoreCase("Home Loan")) {
            l = new HomeLoan(CustomerLoan.laonstatus.Pending);

        } else if (loanType.equalsIgnoreCase("veichleloan") || loanType.equalsIgnoreCase("veichle Loan")) {
            l = new VeichleLoan(CustomerLoan.laonstatus.Pending);
        } else {
            l = new PersonalLoan(CustomerLoan.laonstatus.Pending);
        }we us the loan application here*/
        /*System.out.println("loan id " + l.getLoanId());
        l.setLoanType(loanType);
        l.setLoanAmount(loanAmount);
        l.setTenure(tenure);
        l.setRoi(roi);
        l.setmonthlyExpanse(monthlyExpanse);
        l.setmonthlyIncome(monthlyIncome);
        l.setRepaymentfrequency(repaymentFrequency);
        l.setStatus(CustomerLoan.laonstatus.Pending);
        l.setYear(year);
        l.setMonth(month);
        l.setDay(day);
        LocalDate ld = LocalDate.of(l.getYear(), l.getMonth(), l.getDay());
        System.out.println("the disbursal date will be" + ld);

        l.setloanDisbursalDate(ld);
        System.out.println(l.toString());


       Double emi = l.calcemi();
       System.out.println("EMI IS "+emi);
        Double calculateAmount = l.calcloanamount();
        System.out.println("Maximum Eligible loan Amount "+calculateAmount);
        l.repymentschedule();
        System.out.println("e the late penalty schedule");

        l.calcpenalty(emi);*/









        }
    }

