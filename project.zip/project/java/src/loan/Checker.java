package loan;

public interface Checker {

    public void  approverejectloan(int loanAppliocationId,double monthlyIncome,double monthlyExpanse);
    public  void getallactiveloandetail();
    public void getLoandetails(int loanAccountno);
    public  boolean removeloanAccount(int loanAccountno);
    public void loanDisbursal(int loanId);

}
