package loan;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Creation {
    public static void makecustomer() {
        Scanner sc = new Scanner(System.in);
        System.out.println("are u old customer or new customer");
        String c1=sc.next();
        if(c1.equalsIgnoreCase("new"))
        {
            Validations v=new Validations();
            Customer c=new Customer();
            System.out.println("enter the information of customer");
//            sc.nextLine();
            boolean flag= false;
            while(!flag) {
                System.out.println("enter the date");
             //   String str = "24/09/2017";
                LocalDate ld = LocalDate.of(1999, 8, 21);
              /*  DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate date = LocalDate.parse(str, dt);*/
                c.setDateOfBirth(ld);

                flag = v.dob(c.getDateOfBirth());


            }
             flag= false;
            sc.nextLine();
            while(!flag)
            {
                System.out.println("enter customerName");
                c.setCustomerName(sc.nextLine());
                flag=v.name(c.getCustomerName());
            }
            flag= false;
            while(flag==false)
            {
                System.out.println("enter customer contact no");
                c.setContactno(sc.nextLine());
               flag=v.contact(c.getContactno());
            }
            flag=false;
            while(flag==false)
            {
                System.out.println("enter the gmail");
                c.setEmailAddress(sc.nextLine());
                flag=v.mail(c.getEmailAddress());
            }
            flag=false;
            while(flag==false)
            {
                System.out.println("enter the profession");
                c.setProfession(sc.nextLine());
                flag=v.profession(c.getProfession());
            }
            flag=false;
            while(flag==false)
            {
                System.out.println("enter the monthly Expanse");
                c.setTotalMonthlyExpense(sc.nextDouble());
                flag=v.expanse(c.getTotalMonthlyExpense());
            }
            sc.nextLine();
            flag=false;
            while(flag==false)
            {
                System.out.println("enter the Designation");
                c.setDesignation(sc.nextLine());
                flag=v.desg(c.getDesignation());
            }

            flag=false;
            while(flag==false)
            {
                System.out.println("enter the salary");
                c.setMonthlyIncome(sc.nextInt());
                flag=v.income(c.getMonthlyIncome());
            }
            sc.nextLine();
            flag= false;
            while(!flag)
            {
                System.out.println("enter companyName");
                c.setCompanyName(sc.nextLine());
                flag=v.company(c.getCompanyName());
            }

            BankFactory b=new BankFactory();

            Maker m=b.getBank();
       boolean r=m.registerCustomer(c);
       System.out.println(c);
            System.out.println(r);
           /* boolean r1=m.registerCustomer(c2);
            System.out.println(r1);*/
           /* boolean r3=m.registerCustomer(c2);
            System.out.println(r3);*/




        }
        else if(c1.equalsIgnoreCase("old"))
        {
            System.out.println("give the customer Id");
        }

    }
}
