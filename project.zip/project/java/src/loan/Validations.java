package loan;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public class Validations {
    public boolean name(String customerName)
    {

        boolean flag= Pattern.matches("[[A-Za-z]{1,15}[\\s]{1}]+",customerName);
        return flag;
    }
    public boolean contact(String Contact)
    {

       boolean flag=Pattern.matches("[0-9]{10}",Contact);
       return flag;
    }
    public boolean mail(String mail)
    {
        boolean flag= Pattern.matches("[a-zA-z0-9]{1,30}[@][.a-z]{1,10}",mail);
        return flag;
    }
    public boolean profession(String profession) {
        boolean flag = Pattern.matches("[a-zA-Z]{1,15}", profession);
        return flag;
    }
    public boolean expanse(double a) {
       boolean flag=length(a);
       return flag;
    }
    public boolean desg(String a) {
        boolean flag = Pattern.matches("[[A-Za-z]{1,15}[\\s]{1}]+", a);

        return flag;
    }
    public boolean company(String co)
    {

        boolean flag= Pattern.matches("[A-Za-z]{1,15}([\\sA-Za-z]{1,14})*",co);
        return flag;
    }
    public boolean income(double a) {
        boolean flag=length(a);
        return flag;
    }
    public boolean dob(LocalDate ld)
    { String s= ld.format(DateTimeFormatter.ofPattern("dd/MM/YYYY"));
        System.out.println(s);
        boolean m =Pattern.matches("([\\d/]{3})([\\d/]{3})[\\d]{4}",s);
        return m;
    }


    public boolean length(Number k)
    {
        int min=1,max=1000000;

        boolean flag= false;
        if(k instanceof Integer)
        {
            Integer i=(Integer)k;
            if(i>=min && i<=max)
            {
                flag=true;
                System.out.println(flag);

            }
            else
            {
                System.out.println(flag);
            }
        }
        else if (k instanceof Double)
        {
            Double i=(Double)k;
            if(i>=min && i<=max)
            {
                flag=true;
                System.out.println(flag+"1");

            }
            else
            {
                System.out.println(flag);
            }
        }
        else
        {
            System.out.println(flag);
        }
        return flag;
    }
}