package loan;

import java.util.Scanner;

//
    /*public static void main(String args[]) {
        int k;

        double LoanAmount,rate;
        String typeoflaon;
        int tenure,repaymentfreq,applicationid;
        Ba
        Scanner sc=new Scanner(System.in);
        Maker make = b;
        *//*Homeloan hl=new Homeloan(Customerloan.laonstatus.Pending);
        Veichleloan vi=new Veichleloan(Customerloan.laonstatus.Pending);
        Personalloan p=new Personalloan((Customerloan.laonstatus.Pending));*//*
        do {

            System.out.println("Enter 1 for apply Loan ");
            System.out.println("Enter 2 for track Loan status");
            System.out.println("Enter 3 for Approve reject loan");
            System.out.println("Enter 4 for All Active Loan Details ");
            System.out.println("Enter 4 for get Lon Details");
            System.out.println("Enter 5 for remove Loan Account");
            k=sc.nextInt();
            switch(k) {

                case 1:
                    System.out.println("Enter the Loan Amount ");
                    LoanAmount = sc.nextDouble();
                    System.out.println("enter the rate");
                    rate = sc.nextDouble();
                    System.out.println("enter type of loan ");
                   typeoflaon =sc.next();
                   //sc.nextLine();
                    System.out.println("enter the tenure ");
                    tenure =sc.nextInt();
                    System.out.println("enter the repayment frequency ");
                    repaymentfreq =sc.nextInt();
                    System.out.println(typeoflaon);
                    b.applylaon(LoanAmount,rate,tenure,typeoflaon,repaymentfreq);
                    break;
                case 2:
                    System.out.println("enter the application id");
                    applicationid=sc.nextInt();
                    b.trackloanstatus(applicationid);
                    break;
                case 3:
                    System.out.println("Enter the application id");
                    applicationid=sc.nextInt();
                   *//* b.approverejectloan(applicationid);*//*
                    break;
                case 4:
                    b.getallactiveloandetail();
                    break;
            }
        }while(k<5);

    }

}
*/