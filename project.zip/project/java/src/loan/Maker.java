package loan;

public interface Maker {
    public boolean registerCustomer(Customer c);
    public Customer findCustomer(int customerId);
    public int applylaon(double LoanAmount, Double roi, int tenure, String typeoflaoan, int repaymentfrequency);
     public String trackloanstatus ( int loanApplicationId);
   public  void getallactiveloandetail();
   public void getLoandetails(int loanAccountno);
    public void loanDisbursal(int loanId);
    public void payEMI(int loanAccountNumber, double emiAmount, int month);

}
