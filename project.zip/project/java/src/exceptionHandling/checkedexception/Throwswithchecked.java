package exceptionHandling.checkedexception;

import java.io.FileReader;
import java.io.IOException;


public class Throwswithchecked {
    public void fun() throws IOException {
        System.out.println("Start the method");
        fun2();
        System.out.println("end the method");

    }
    public void fun2() throws IOException{
        System.out.println("Start the method");
        FileReader file = new FileReader("C:\\test\\a.txt");
        System.out.println("end the method");



    }

    public static void main(String arg[])   {
        Throwswithchecked pr=new Throwswithchecked();
try {
    pr.fun();
}
catch(Exception e)
{
    System.out.println(e.getMessage());

}

    }


}
