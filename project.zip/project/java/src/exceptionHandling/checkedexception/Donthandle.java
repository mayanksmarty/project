package exceptionHandling.checkedexception;

import java.io.IOException;

public class Donthandle {

    public void fun2()  {

        try {
            System.in.read();//we are forcing this to do try and catch otherwise it is showing error without throws.
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        public static void main(String arg[]) {
            Donthandle pr = new Donthandle();


                pr.fun2();



    }
}
