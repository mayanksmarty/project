package exceptionHandling.checkedexception;

import java.io.FileReader;
import java.io.IOException;

public class Throwwithchecked {
    public void fun2() throws IOException {
System.out.println("Start the method");
        FileReader file = new FileReader("C:\\test\\a.txt");
        throw new IOException();
    }

    public static void main(String arg[]) {
        Throwwithchecked pr = new Throwwithchecked();

        try {
            pr.fun2();

        } catch (IOException e) {
            System.out.println("Throw with checked exception");

        }

    }
}
