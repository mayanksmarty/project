package exceptionHandling;

public class Tryfinally {
    public static void main(String args[])
    {
        try
        {
            int a=5/0;

        }
        finally
        {
            System.out.println("No Catch given");
        }
    }
}
