package exceptionHandling;

public class Multiplecatch {
    public static void main(String[] args) {

        try{
            int a[]=new int[4];
            a[4]=10/0;
        }
        catch(ArithmeticException e)
        {
            System.out.println("Arithmetic Exception occurs");
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("ArrayIndexOutOfBounds Exception occurs");
        }
        catch(Exception e)
        {
            System.out.println("Main Exception occurs");
        }
        System.out.println("rest of the code");
    }
}
