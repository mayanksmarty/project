package exceptionHandling.uncheckedexception;

public class Donthanleunchecked {
    public void fun()
    {
        int a=10;
        int b=0;
        int c=a/b;

    }
    public static void main(String args[]) {
        Donthanleunchecked sm = new Donthanleunchecked();
        try {
            sm.fun();
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage());
        }
    }
}
