package exceptionHandling.uncheckedexception;

public class Samemethod {
public void fun()
{
    int a=10;
    int b=0;
    int c=a/b;
    throw new ArithmeticException();
}
public static void main(String args[]) throws  ArithmeticException
{
    Samemethod sm=new Samemethod();
    try {
        sm.fun();
    }
    catch(ArithmeticException e)
    {
        System.out.println(e.getMessage());
    }

}
}
