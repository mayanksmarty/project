package exceptionHandling.uncheckedexception;

public class throwswithunchecked {
    public void fun()throws ArithmeticException
    {
        int a=10;
        int b=0;
        int c=a/b;

    }
    public static void main(String args[]) {
        Samemethod sm = new Samemethod();
        try {
            sm.fun();
        } catch (ArithmeticException e) {
            System.out.println(e.getMessage() + " will show the error");
        }
    }
}
