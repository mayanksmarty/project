package exceptionHandling;

import java.io.*;

public class Propogation {
    public void fun() throws IOException
    {
        fun2();

    }
    public void fun2()throws IOException {

        FileReader file = new FileReader("C:\\test\\a.txt");
        throw new IOException();


    }

        public static void main(String arg[])   {
            Propogation pr=new Propogation();

            try{pr.fun();

            }
            catch (IOException e){
                System.out.println("IOException should be handled");

            }

            }

        }




