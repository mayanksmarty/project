package exceptionHandling;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;

import java.io.IOException;

public class Foo {
    public void foos() throws IOException{
        System.out.println("Satrt of method");
        bar();
        System.out.println("End of of method");




    }
    public void bar()throws IOException
    {
        throw new IOException();
    }

    public static void main(String[] args) {
        Foo f=new Foo();
        try {
            f.foos();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
