package exceptionHandling;

public class Trycatchfinally {

    public static void main(String args[]) {

            try {
                int a[] = new int[2];
                System.out.println("Access element three :" + a[3]);
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Exception thrown  :" + e);
            }
            finally
            {
                System.out.println("Exception will definately occur");
            }
            System.out.println("Out of the block");
        }
}
