package innerclasses;

public class Outerclass {
   private String name;
   private int id;




    class Inner {
        private int id1;
        private String Name1;

        public Inner(int id1, String name1) {
            this.id1 = id1;
           this.Name1 = name1;
        }

     public   Inner getobject()
        {
            Inner c=new Inner(1,"a");
            return c;
        }
    }
}

