package innerclasses;

public class LocalInnerclass {
    Runnable method1()
    {
          final int methodvar1=50;//or we can write  public static or any members int methodvar1=50;
       class LocalInnerclass1 implements Runnable{
            private int x;//here static cant be created
           public void run()
           {
               System.out.println("run"+x);
               System.out.println(methodvar1);
           }

       }
       return new LocalInnerclass1();
    }

    public static void main(String[] args) {
        LocalInnerclass l=new LocalInnerclass();
        Runnable run1 =l.method1();
        run1.run();
    }

}
