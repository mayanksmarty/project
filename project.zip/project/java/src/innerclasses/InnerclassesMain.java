package innerclasses;

import innerclasses.Outerclass;

public class InnerclassesMain {
    public static void main(String[] args) {


        Outerclass oc = new Outerclass();
        Outerclass.Inner c = oc.new Inner(1, "a");
        System.out.println(c);
        Outerclass.Inner ic = c.getobject();
        System.out.println(ic);

    }
}
