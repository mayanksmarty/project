package innerclasses;

public class anonymousclass {
    Runnable method1()
    {
        final int methodvar1=50;//or we can write  public static or any members int methodvar1=50;
        class LocalInnerclass1 implements Runnable{
            private int x;//here static cant be created
            public void run()
            {

                System.out.println("run"+x);
                System.out.println(methodvar1);
            }

        }
        return new LocalInnerclass1();
    }

    public static void main(String[] args) {
        LocalInnerclass l=new LocalInnerclass();
        Runnable runnable=new Runnable(){
            @Override
            public void run()
            {
                System.out.println("Anonymous class");
            }
        };
        runnable.run();
        Runnable l1= l.method1();
        l1.run();
    }

}
