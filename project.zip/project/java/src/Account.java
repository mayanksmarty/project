public class Account {
    double balance;

    void withdraw(double amount)  {
        System.out.println("Withdraw method called");
        synchronized (this) {
            double bal = balance;
            bal = bal - amount;
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            balance = bal;
        }

    }

 synchronized  void deposit(double amount)  {
        System.out.println("Deposit method called");
        double bal = balance;
        bal = bal + amount;
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        balance = bal;
    }
}
