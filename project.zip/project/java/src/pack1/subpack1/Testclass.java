package pack1.subpack1;

import pack1.MyClass;

public class Testclass {
    public static void main(String[] args) {
        MyClass m=new MyClass();
        m.method1();
        System.out.println("only public can be accessed");
    }
}
