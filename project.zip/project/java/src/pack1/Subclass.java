package pack1;

public class Subclass extends MyClass{
    public static void main(String[] args) {
        MyClass m=new MyClass();
        m.method1();
        m.method3();
        m.method4();
        System.out.println("only public protected default can be accessed in same package");
    }

}
