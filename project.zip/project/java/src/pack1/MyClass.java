package pack1;

public class MyClass {
    public void method1() {
        System.out.println("method1");
    }

    private void method2() {
        System.out.println("method2");
    }

    protected void method3() {
        System.out.println("method3");
    }

    void method4() {
        System.out.println("method 4");
    }


}
