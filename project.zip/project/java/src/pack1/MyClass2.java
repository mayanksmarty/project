package pack1;

public class MyClass2 {


    public static void main(String[] args) {
        MyClass obj=new MyClass();
        obj.method1();
        obj.method3();
        obj.method4();

    }
}
