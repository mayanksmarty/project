package lambdafunction;

import java.util.Scanner;

public class cust {
    private double sal;
    private  int age;
    private String name;


    public cust(double sal, int age, String name) {
        this.sal = sal;
        this.age = age;
        this.name=name;
    }

    public double getSal() {
        return sal;
    }



    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Cust{" +
                "sal=" + sal +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }

    public static void main(String[] args) {


        cust cust[] = new cust[100];

        Scanner sc = new Scanner(System.in);
        int age;
        double salary;
        String name;
        System.out.println("enter the customer object you want to print");
        int n=sc.nextInt();
        for(int i=0;i<n;i++) {

            System.out.println("enter the age");
            age = sc.nextInt();
            System.out.println("enter the salary");
            salary = sc.nextDouble();
            sc.nextLine();
            System.out.println("enter the name");
            name = sc.nextLine();

            cust[i] = new cust(salary, age, name);

        }
        for(int j=0;j<n;j++)
        {
            System.out.println(cust[j].getAge());
            System.out.println(cust[j].getName());
            System.out.println(cust[j].getSal()) ;
        }
        for(int j=0;j<n;j++)
        {
            System.out.println(cust[j].toString());
        }


        Functionalinterface inter = e1 -> e1.sal > 15000;

        for (int i =0 ;i < n; i++) {
            if (inter.abstractFun(cust[i])) {
                System.out.println(cust[i].name);
            }
        }
        Functionalinterface inter1=e1-> (e1.age>18 && e1.age<25);
        for (int i =0 ;i < n; i++) {
            if (inter1.abstractFun(cust[i])) {
                System.out.println(cust[i].name);
            }
        }


    }

}
