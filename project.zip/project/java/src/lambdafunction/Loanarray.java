package lambdafunction;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Loanarray {
    private int LoanAccounts;
    private String Status;
    private String Emi;

    @Override
    public String toString() {
        return "Loanarray{" +
                "LoanAccounts=" + LoanAccounts +
                ", Status='" + Status + '\'' +
                ", Emi='" + Emi + '\'' +
                '}';
    }

    public int getLoanAccounts() {
        return LoanAccounts;
    }

    public String getStatus() {
        return Status;
    }

    public String getEmi() {
        return Emi;
    }

    public Loanarray(int loanAccounts, String status, String emi) {
        LoanAccounts = loanAccounts;
        Status = status;
        Emi = emi;
    }


    public static Predicate<Loanarray> isPending() {
        return p -> p.getEmi() .equalsIgnoreCase("Pending") && p.getStatus().equalsIgnoreCase("Active");
    }
    public static List<Loanarray> filter (List<Loanarray> employees,
                                                   Predicate<Loanarray> predicate)
    {
        return employees.stream()
                .filter( predicate )
                .collect(Collectors.<Loanarray>toList());
    }
}
