package lambdafunction;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static lambdafunction.Loanarray.filter;
import static lambdafunction.Loanarray.isPending;

public class MainLoan {
    public static void main(String[] args) {
        List<Loanarray> users = new ArrayList<Loanarray>();
        users.add(new Loanarray(1000,"Active","pending"));
        users.add(new Loanarray(1001,"Closed","pending"));
        users.add(new Loanarray(1003,"Closed","Approved"));
        users.add(new Loanarray(1004,"Active","pending"));
       Predicate<Loanarray> p1 = c -> c.getStatus().equals("Active") &&
               c.getEmi().equals("pending");
        users.stream().filter(p1).forEach(System.out::println);
        System.out.println( filter(users, isPending()) );







    }
}
