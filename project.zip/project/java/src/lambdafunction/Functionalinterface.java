package lambdafunction;

public interface Functionalinterface {


    boolean abstractFun(cust customer);
}
