import java.time.LocalDate;
import java.util.Scanner;

public class Loan2  {

    private String LoanType;
    private int LoanId;
    private double loanAmount;
    private int tenure;
    private double roi;

    private double monthlyincome;
    private double monthlyexpanse;
    private static int count = 0;
    public enum laonstatus
    {
        Approved,Rejected,Pending;
    }
    private double emiperMonth;
    private LocalDate loandisbursalDate;
    private double maximumEmi;

    public LocalDate getPaymentdate() {
        return paymentdate;
    }

    public void setPaymentdate(LocalDate paymentdate) {
        this.paymentdate = paymentdate;
    }

    private LocalDate paymentdate;





    public double getMonthlyincome() {
        return monthlyincome;
    }

    public void setMonthlyincome(double monthlyincome) {
        this.monthlyincome = monthlyincome;
    }

    public double getMonthlyexpanse() {
        return monthlyexpanse;
    }

    public void setMonthlyexpanse(double monthlyexpanse) {
        this.monthlyexpanse = monthlyexpanse;
    }


    public int getLoanId() {
        return LoanId;
    }

    private int repaymentfrequency;




    public void setLoanType(String loanType) {
        LoanType = loanType;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public void setRoi(double roi) {
        this.roi = roi;
    }

    public void setEmiperMonth(double emiperMonth) {
        this.emiperMonth = emiperMonth;
    }

    public void setLoandisbursalDate(LocalDate loandisbursalDate) {
        this.loandisbursalDate = loandisbursalDate;
    }

    public void setMaximumEmi(double maximumEmi) {
        this.maximumEmi = maximumEmi;
    }

    public String getLoanType() {
        return LoanType;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public int getTenure() {
        return tenure;
    }

    public double getRoi() {
        return roi;
    }

    public double getEmiperMonth() {
        return emiperMonth;
    }

    public LocalDate getLoandisbursalDate() {
        return loandisbursalDate;
    }

    public double getMaximumEmi() {
        return maximumEmi;
    }

    public int getRepaymentfrequency() {
        return repaymentfrequency;
    }


    public void setRepaymentfrequency(int repaymentfrequency) {
        this.repaymentfrequency = repaymentfrequency;
    }



    laonstatus status;
    public Loan2( laonstatus s) {

        this.LoanId =++count;
        this.status = s;
    }
    void calcemi()
    {
        double expenses=(getMonthlyexpanse() / getMonthlyincome()) / 2;
        double emi=expenses-(expenses*0.20);
        System.out.println(emi);

    }
    void calcloanamount()
    {
    double expenses=(getMonthlyexpanse() / getMonthlyincome()) / 2;
    double emi=expenses-(expenses*0.20);

        double Maximumemi=emi* Math.pow((1+getRoi()),10)/(Math.pow((1+getRoi()),getTenure()));
        System.out.println("maximum eligible loan amount will be "+Maximumemi);
    }
    void repymentschedule()
    {
        int residualvalue=0;
        double interest;
        double principle;
        double loanamount=getLoanAmount();
       double installmentAmount=(getLoanAmount()*(getRoi()/getRepaymentfrequency())-residualvalue*(getRoi()/getRepaymentfrequency())/Math.pow((1+getRoi()/getRepaymentfrequency()),getTenure()))/((1-1/(Math.pow((1+getRoi()/getRepaymentfrequency()),getTenure()))));

        System.out.println("installment amount is "+installmentAmount);
        for( int installmentno=1;installmentno<=getTenure();installmentno++)
        {
            interest= (loanamount * (getRoi()/12) )  ;

            principle=installmentAmount-interest;

            System.out.println("the installment for "+installmentno+" year with insterst and principle"+interest+" and "+principle+"and their installment"+loanamount);
            loanamount=loanamount-principle;
        }
    }
    void calcpenalty()
    {
        Scanner sc=new Scanner(System.in);
        Loanmain2 l1=new Loanmain2();
        LocalDate ld=getLoandisbursalDate();
        double r=getLoanAmount();
        for (long i=1;i<=getTenure();i++)
        {
            LocalDate duedate=ld.plusMonths(i);
            System.out.println(duedate);
            System.out.print("is emi is paid or not:-");
            String a=sc.nextLine();
            if(a.equals("yes")|| a.equals("yes")|| a.equals("YES")|| a.equals("Y"))
            {
                double interest=r*(getRoi()/12);
                double principle=getEmiperMonth()-interest;
                r=r-principle;
            }
            else
            {
                System.out.println("Enter the payment date");
                l1.setDay(sc.nextInt());
                System.out.println("Enter the payment month");
                l1.setMonth(sc.nextInt());
                System.out.println("Enter the payment year");
                l1.setYear(sc.nextInt());
                sc.nextLine();//for the next entry with the int and string
                LocalDate ld1= LocalDate.of(l1.getYear(),l1.getMonth(),l1.getDay());
                setPaymentdate(ld1);
                int l=duedate.getYear();
                int l3=duedate.getMonthValue();
                int l4=duedate.getDayOfMonth();
                int l5=getPaymentdate().getYear();
                int l6=getPaymentdate().getMonthValue();
                int l7=getPaymentdate().getDayOfMonth();
                int q=l5-l;
                int w=l6-l3;
                int e=l7-l4;

                double k=q*360+Math.abs(w)*30+Math.abs(e);
                 double interest=getEmiperMonth()*(k/30);
                 System.out.println(interest);
                 i=i+w;


            }
        }


    }



}
