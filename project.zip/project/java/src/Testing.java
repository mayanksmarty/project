/*import java.text.DateFormat;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class Testing {
    public static void main(String args[]) {
        Date currentdate = new Date();
        System.out.println(DateFormat.format(currentdate));
    }


}*/
