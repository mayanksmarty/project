package collection;

import java.util.*;

public class Treeset {
    public static void main(String[] args) {
        TreeSet<Employee> l=new TreeSet<Employee>();
        Employee l1=new Employee(2000,12,"mayank");
        Employee l2=new Employee(2000,12,"mayank");
        Employee l3=new Employee(2000,13,"mayank");
        //Treeset always uses Compareable and compare statement to execute the statement


        l.add(l1);
        l.add(l2);
        l.add(l3);
        l.forEach(System.out::println);
        System.out.println("Hash set");
        HashSet<Employee> h=new HashSet<Employee>();
        Employee h1=new Employee(2000,12,"mayank");
        Employee h2=new Employee(2000,12,"mayank");
        Employee h3=new Employee(2000,13,"mayank");
        Employee h4=new Employee(24000,13,"mayank");

        h.add(h1);
        h.add(h2);
        h.add(h4);
        h.add(h3);
        h.remove(h1);
        h.forEach(System.out::println);
        System.out.println("TreeMap");
        Map<Integer, Employee> map=new TreeMap<>();
        map.put(1,new Employee(100,12,"anu"));
        Set< Map.Entry< Integer,Employee> > st = map.entrySet();

        for (Map.Entry< Integer,Employee> me:st)
        {
            System.out.print(me.getKey()+":");
            System.out.println(me.getValue());
        }
      /*  Set<Integer> set = new TreeSet<Integer>((e1, e2) -> Integer.compare(e1, e2));*/

    }
}
