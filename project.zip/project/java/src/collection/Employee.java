package collection;


import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Objects;

public class Employee implements Comparable <Employee>, Comparator<Employee> {
    private double sal;
    private  int age;
    private String name;


    public Employee(double sal, int age, String name) {
        this.sal = sal;
        this.age = age;
        this.name=name;
    }

    public double getSal() {
        return sal;
    }



    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Cust{" +
                "sal=" + sal +
                ", age=" + age +
                ", name='" + name + '\'' +
                '}';
    }
    @Override
    public int compareTo(Employee o) {
        if(this.age>o.age)
            return 1;
        else if(this.age<o.age)
            return -1;
        else return 0;

    }

    @Override
    public int compare(Employee o1, Employee o2) {
        return o1.name.compareTo(o2.name);
    }

    @Override
    public boolean equals(Object o) {
        System.out.println("equalscode");
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return Double.compare(employee.sal, sal) == 0 &&
                age == employee.age &&
                Objects.equals(name, employee.name);
    }

    @Override
    public int hashCode() {
        System.out.println("hashcode");
        return Objects.hash(sal, age, name);
    }

    public static void main(String[] args) {
        LinkedList<Employee>list=new LinkedList<Employee>();
        list.add(new Employee(2000,12,"mayank"));
        list.add(new Employee(2000,11,"mayank"));
        list.set(1,(new Employee(1000,11,"aman")));//It can override the 2nd position
        list.add(new Employee(2000,16,"mayank"));
       Collections.sort(list);

        list.forEach(System.out::println);
    }



}
