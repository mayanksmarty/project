import java.time.LocalDate;

public class Customerloan1 {
   private int customerId;
   private  String customerName;
   private LocalDate dateofbirth;
    private String contactno;
    private  String emailAddress;
    private   String profession;
    private  double totalMonthlyexpense;
    private   String designation;
    private  String companyname;
    private double monthlyIncome;
    private static int count=0;


    public String getContactno() {
        return contactno;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }



    public void setProfession(String profession) {
        this.profession = profession;
    }

    public void setTotalMonthlyexpense(double totalMonthlyexpense) {
        this.totalMonthlyexpense = totalMonthlyexpense;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }


    public String getCompanyname() {
        return companyname;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public String getProfession() {
        return profession;
    }

    public double getTotalMonthlyexpense() {
        return totalMonthlyexpense;
    }

    public String getDesignation() {
        return designation;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }

    public LocalDate getDateofbirth() {
        return dateofbirth;
    }



    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Customerloan1( LocalDate dateofbirth, String emailAddress) {
        this.customerId = ++count;
        this.dateofbirth = dateofbirth;
        this.emailAddress = emailAddress;
    }
    double dbr() {
        double dbr = (getTotalMonthlyexpense() - getMonthlyIncome()) ;
        return dbr;
    }
    double emi() {
        double expenses = (getTotalMonthlyexpense() - getMonthlyIncome()) / 2;
        double emi=expenses-(expenses*0.20);
        return emi;

    }

}
