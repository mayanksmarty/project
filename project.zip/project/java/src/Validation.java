import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Validation {

    public static void main(String ags[]) {
        Scanner sc = new Scanner(System.in);
        Validation val = new Validation();
        Number k;
        boolean flag = false;
        Loan2 l = new Loan2(Loan2.laonstatus.Pending);
        LocalDate ld = LocalDate.of(1999, 8, 21);
        Customerloan1 c = new Customerloan1(ld, "mayankmittal211@gmail.com");
       // SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
      //String strDate= formatter.format(ld);
      //   String dateToStr = DateFormat.getInstance().format(ld);
       // boolean p = Pattern.matches("dd/MM/yyyy",strDate );
      //  System.out.println(p);



        do {
            System.out.println("enter company name");
            c.setCompanyname(sc.nextLine());
            String r = c.getCompanyname();
            boolean v = Pattern.matches("[a-zA-Za0-9]{1,10}[$\\s]{1,2}", r);
            //System.out.println(Pattern.matches("[a-zA-Za$0-9\\s]{1,10}[a-zA-Za$0-9]", r));
            if (v == true) {

                break;
            }
            System.out.println("Invalid  input Pls enter again");
        } while (flag == false);

           flag=false;
        while (flag== false)
        {
            System.out.println("enter customer Name");
            c.setCustomerName(sc.nextLine());
            flag=Pattern.matches("[[A-Za-z]{1,15}[\\s]{1}]+", c.getCustomerName());
        }
        flag=false;
          while (flag == false) {

            System.out.println("enter Loan Type");
            l.setLoanType(sc.nextLine());
            String a = l.getLoanType();
            flag = Pattern.matches("[a-zA-Z]{1,15}", a);
            System.out.println(flag);

            // System.out.println("Invalid  input Pls enter again");
        }
          flag= false;
          while(flag==false)
          {
              System.out.println("enter customer contact no");
              c.setContactno(sc.nextLine());
              flag=Pattern.matches("[0-9]{10}",c.getContactno());
          }
        flag= false;
        while(flag==false)
        {
            System.out.println("enter the profession");
            c.setProfession(sc.nextLine());
            flag=Pattern.matches("[a-zA-Z]{1,15}",c.getDesignation());
        }
        flag=false;
        while(flag==false)
        {
            System.out.println("enter the customer designation");
            c.setDesignation(sc.nextLine());
            flag=Pattern.matches("[a-zA-Z]{1,15}",c.getDesignation());
        }

          flag=false;
        while (flag == false) {
            System.out.println("enter Loan Amount");
            l.setLoanAmount(sc.nextDouble());
            k = l.getLoanAmount();
            flag = val.length(k);

        }
        flag=false;
        while (flag == false) {
            System.out.println("enter the tenure");
            l.setTenure(sc.nextInt());
            Number o = l.getTenure();
            flag = val.length1(o);

        }
        flag=false;
        while (flag == false) {
            System.out.println("enter the roi");
            l.setRoi(sc.nextDouble());
            k = l.getRoi();
            flag = val.length1(k);

        }
        flag=false;
        while (flag == false)
        {
            System.out.println("enter repayment frequency");
            l.setRepaymentfrequency(sc.nextInt());
            k=l.getRepaymentfrequency();
            flag=val.length1(k);
        }
        flag=false;
        while (flag == false)
        {
            System.out.println("enter emi");
            l.setEmiperMonth(sc.nextInt());
            k=l.getEmiperMonth();
            flag=val.length(k);
        }
        flag=false;
        while (flag == false)
        {
            System.out.println("enter monthly expanse");
            l.setMonthlyexpanse(sc.nextInt());
            k=l.getMonthlyexpanse();
            flag=val.length(k);
        }

          flag=false;
        while (flag==false)
        {
            System.out.println("validation fo gmail address");
            flag=Pattern.matches("[a-zA-z0-9@]{1,30}[.a-z]{5}",c.getEmailAddress());
        }


















    }
    public boolean length1(Number k)
    {
        int min=1,max=1000;

        boolean flag= false;
        if(k instanceof Integer)
        {
            Integer i=(Integer)k;
            if(i>=min && i<=max)
            {
                flag=true;
                System.out.println(flag);

            }
            else
            {
                System.out.println(flag);
            }
        }
        else if (k instanceof Double)
        {
            Double i=(Double)k;
            if(i>=min && i<=max)
            {
                flag=true;
                System.out.println(flag);

            }
            else
            {
                System.out.println(flag);
            }
        }
        else
        {
            System.out.println(flag);
        }
        return flag;
    }
    public boolean length(Number k)
    {
        int min=1,max=1000000;
        int count=1;
        boolean flag= false;
        if(k instanceof Integer)
        {
            Integer i=(Integer)k;
            if(i>=min && i<=max)
            {
                flag=true;
                System.out.println(flag);

            }
            else
            {
                System.out.println(flag);
            }
        }
        else if (k instanceof Double)
        {
            Double i=(Double)k;
            if(i>=min && i<=max)
            {
                flag=true;
                System.out.println(flag);

            }
            else
            {
                System.out.println(flag);
            }
        }
        else
        {
            System.out.println(flag);
        }
        return flag;
    }
}
