class Ltv
{
public static void main(String args[])
{
int loanAmount;
int propertyvalue;

double LTV;
loanAmount=160000;
propertyvalue=100000;
LTV=loanAmount/propertyvalue;
if(LTV<=.8)
{
System.out.println(" Maximum LTV will be"+LTV);
}
else
{
System.out.println("Not Allowed to give");
}

}
}


