package basic;

import java.util.List;
import java.util.Map;

public class User {
    private String name;
    private int empId;
    private double salary;
    private char desig;
    /*private List<String> phoneno;
    private Map<Integer,String> email;
*/
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public char getDesig() {
        return desig;
    }

    public void setDesig(char desig) {
        this.desig = desig;
    }

   /* public List<String> getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(List<String> phoneno) {
        this.phoneno = phoneno;
    }

    public Map<Integer, String> getEmail() {
        return email;
    }

    public void setEmail(Map<Integer, String> email) {
        this.email = email;
    }*/

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", empId=" + empId +
                ", salary=" + salary +
                ", desig=" + desig +
                '}';
    }
}
