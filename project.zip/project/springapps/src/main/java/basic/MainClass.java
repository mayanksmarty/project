package basic;

import mvc.Presentation;
import mvc.Service;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.SQLOutput;

public class MainClass {
public static void main(String[] args) {

	//Loading Spring container in memory
	AbstractApplicationContext ctx = new
			ClassPathXmlApplicationContext("/spring.xml");
	
	Employee emp = (Employee)ctx.getBean("empp");
	System.out.println(emp.getName());
	System.out.println(emp.getEmpId());
	System.out.println(emp.getSalary());
	System.out.println(emp.getDesig());
	System.out.println("#############");
	Employee emp1=(Employee)ctx.getBean("emp2");
	System.out.println(emp1.getSalary());
	System.out.println(emp1.getEmpId());
	System.out.println("#############");
	Employee emp8=(Employee)ctx.getBean("emp8");
	System.out.println(emp8.getPhoneno());
	System.out.println(emp8.getEmail());
	System.out.println(emp8.getAddr());
	System.out.println(emp8.toString());
	System.out.println("#############");
	Presentation pr=(Presentation)ctx.getBean("Presentation") ;
	System.out.println(pr.getSer());
	System.out.println("#############");
	Service sr=(Service)ctx.getBean("service") ;
	System.out.println(sr.getDao());
	System.out.println("#############");


	/*Employee emp1 = (Employee)ctx.getBean("emp2");*/
	/*System.out.println(emp.getName());
	Employee em = new Employee();
	Employee emp1 = (Employee)ctx.getBean("emp2");
	System.out.println(emp1.getName());*/
	/*Employee emp7= (Employee)ctx.getBean("emp3");
	System.out.println(emp7.getName());*/
	
	Employee emp6= (Employee)ctx.getBean("emp");
	System.out.println(emp6.getName());// it show null as salary is in string
	
	/*Employee emp1 = (Employee)ctx.getBean("emp4");
	System.out.println(emp1.getEmpId());*/
	
	/*Employee emp2 = (Employee)ctx.getBean("emp4");
	System.out.println(emp2.getEmpId());
	Employee emp3 = (Employee)ctx.getBean("emp4");
	System.out.println(emp3.getEmpId());*/
	
	//ctx.registerShutdownHook();
	ctx.close();
	//System.out.println(emp.getName());
	
	
	}
}







