package basic;

/* Spring Bean */


import org.springframework.beans.factory.annotation.Autowired;
import springpacakge.Address;

import java.util.List;
import java.util.Map;

public class Employee{
	private String name;
	private int empId;
	private double salary;
	private char desig;
	private List<String> phoneno;
	private Map<Integer,String> email;

	@Override
	public String toString() {
		return "Employee{" +
				"addr=" + addr +
				'}';
	}
@Autowired
	private Address addr;

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public List<String> getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(List<String> phoneno) {
		this.phoneno = phoneno;
	}

	public Map<Integer, String> getEmail() {
		return email;
	}

	public void setEmail(Map<Integer, String> email) {
		this.email = email;
	}

	public Employee() {
		
		System.out.println("Constructor ");
	}

	public void setDesig(char s){
		desig = s;
	}
	public char getDesig(){
		return desig;
	}

	public Employee(Double sal, int id) {
		System.out.println("2-arg Constructor with double and int");
		this.empId = id;
		this.salary = sal;
	}
	public Employee( String name,String salary ) {
		System.out.println("2 arg constructor");

		/*this.salary = salary;*/
	}
	public Employee(int id, double salary,  String name) {
		System.out.println("3 arg Constructor with int double string");
		this.name = name;
		this.empId = id;
		this.salary = salary;
	}
	public Employee(int id, String name,  double salary) {
		System.out.println("3 arg Constructor");
		this.name = name;
		this.empId = id;
		this.salary = salary;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public void calSalary(int x) {
		System.out.println("Calculate Salary");
	}



	
	//Init Method
	public void init(){
		System.out.println("Inside Init");
	}
	
	
	public void destroy(){
		System.out.println("Custom  Destroy Method");
	}

	
	public void calSalary() {
		System.out.println("Calculate Salary");
		
	}

}
