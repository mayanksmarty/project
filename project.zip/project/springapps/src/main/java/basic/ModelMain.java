package basic;

import mvc.Presentation;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ModelMain {
    public static void main(String[] args) {
        ApplicationContext ctx = new AnnotationConfigApplicationContext(Configurations.class);
        Scanner sc=new Scanner(System.in);
User u=(User)ctx.getBean("getuser");
System.out.println("enter the name");
u.setName(sc.nextLine());
System.out.println("enter the id");
u.setEmpId(sc.nextInt());
System.out.println("enter the designation");
u.setDesig(sc.next().charAt(0));
        System.out.println("enter the salary");
u.setSalary(sc.nextDouble());


//        Presentation p=(Presentation)ctx.getBean("getpresentation");
        Presentation p=  ctx.getBean(Presentation.class);
        p.insert(u);
        System.out.println("enter the id to print");
        u.setEmpId(sc.nextInt());
        int i=u.getEmpId();
        User u1= p.getuser(i);
       System.out.println(u1);
       System.out.println("details of list");
        List<User>list=new ArrayList<>();
        list=p.getuserdetails();



        /*for(User model : list) {
            System.out.println(model.getName());
            System.out.println(model.getDesig());
            System.out.println(model.getDesig());
            System.out.println(model.getEmpId());
        }*/
        list.forEach(System.out::println);
        System.out.println("Required Updation");
        System.out.println("enter the id");
        int id=sc.nextInt();
        sc.nextLine();
        System.out.println("enter the name");
      String name=sc.nextLine();


        System.out.println("enter the designation");
        char desig=(sc.next().charAt(0));
        System.out.println("enter the salary");
        double salary=(sc.nextDouble());
      boolean b=  p.update(id,name,salary,desig);
      if(b== true)
      {
          System.out.println("updated");
      }
      else
      {
          System.out.println("not updated");
      }



    }




}
