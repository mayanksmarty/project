package basic;

import mvc.Dao;
import mvc.Presentation;
import mvc.Service;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

@Configuration
@ComponentScan("mvc")
public class Configurations {

    @Bean
    public DataSource  getDataSource() {
        DriverManagerDataSource datasource = new DriverManagerDataSource();
        Resource resource=  new ClassPathResource("/db.properties");
        Properties pro=null;
        try
        {
            pro= PropertiesLoaderUtils.loadProperties(resource);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }


        datasource.setDriverClassName(pro.getProperty("driver"));
        datasource.setUrl(pro.getProperty("url"));
        datasource.setUsername(pro.getProperty("username"));
        datasource.setPassword(pro.getProperty("password"));
        return datasource;
    }
   /* @Bean(autowire = Autowire.BY_TYPE)
    public Presentation getpresentation()
    {
        return new Presentation();
    }
    @Bean(autowire = Autowire.BY_TYPE)
    public Service getpreservice()
    {
       return new Service();
    }*/
    @Bean
    public   User getuser()
    {
        User u = new User();



return u;
    }
   /* @Bean(autowire = Autowire.BY_TYPE)
    public Dao getdao()
    {
       return new Dao();
    }

*/


}
