package springpacakge;

import java.util.List;
import java.util.Map;

public class Address {
    private List<String> city;
    private Map<Integer,String> state;

    public List<String> getCity() {
        return city;
    }

    public void setCity(List<String> city) {
        this.city = city;
    }

    public Map<Integer, String> getState() {
        return state;
    }

    public void setState(Map<Integer, String> state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "address{" +
                "city=" + city +
                ", state=" + state +
                '}';
    }

    public Address()
    {
        System.out.println("constructor");
    }
}
