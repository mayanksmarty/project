package mvc;

import basic.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
@Repository
public class Dao {
    public Dao() {
    }
@Autowired
    private DataSource dataSource;

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    PreparedStatement psInsert;
    PreparedStatement psSelect;
    PreparedStatement psUpdate;

    public void insert(User u) {
        Connection con = null;
        int r = 0;
        try {

            con = dataSource.getConnection();
            psInsert = con.prepareStatement("insert into mayankusers values(?,?,?,?)");

            psInsert.setString(1, u.getName());

            psInsert.setInt(2, u.getEmpId());
            psInsert.setDouble(3, u.getSalary());
            psInsert.setString(4, String.valueOf(u.getDesig()));
            r = psInsert.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


    }

    public User getuser(int employeeid) {
        Connection con = null;
        User u1 = null;
        int r = 0;
        try {

            con = dataSource.getConnection();
            psSelect = con.prepareStatement("select * from mayankusers where empId=?");
            psSelect.setInt(1, employeeid);
            ResultSet rs = psSelect.executeQuery();
            if (rs.next()) {
                u1 = new User();
                u1.setSalary(rs.getDouble(3));
                u1.setEmpId(rs.getInt(2));
                u1.setName(rs.getString(1));
                u1.setDesig(rs.getString(4).charAt(0));
                return u1;
            }


        } catch (SQLException e) {
            e.printStackTrace();

        }

        return u1;
    }

    public List<User> getuserdetails() {
        Connection con = null;
        User u1 = null;
        List<User> list = new ArrayList<User>();
        int r = 0;
        try {

            con = dataSource.getConnection();
            psSelect = con.prepareStatement("select * from mayankusers");
            ResultSet rs = psSelect.executeQuery();
            while (rs.next()) {
                u1 = new User();
                u1.setSalary(rs.getDouble(3));
                u1.setEmpId(rs.getInt(2));
                u1.setName(rs.getString(1));
                u1.setDesig(rs.getString(4).charAt(0));
                list.add(u1);
            }


        } catch (SQLException e) {
            e.printStackTrace();

        }

        return list;
    }

    public boolean update(int employeeid, String name, double salary, char desig) {
        Connection con = null;
        User u1 = null;
        int r = 0;
        try {

            con = dataSource.getConnection();
            psUpdate = con.prepareStatement("update mayankusers set names=?,salary=?,desig=? where empId=?");
            psUpdate.setString(1, name);

            psUpdate.setDouble(2, salary);
            psUpdate.setString(3, String.valueOf(desig));
            psUpdate.setInt(4, employeeid);
            psUpdate.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return false;
    }
}


