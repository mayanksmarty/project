package mvc;

import basic.User;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
@org.springframework.stereotype.Service
public class Service {
    @Autowired
    private Dao dao;

    public Dao getDao() {
        return dao;
    }

    /*@Override
    public String toString() {
        return "Service{" +
                "dao=" + dao +
                '}';
    }*/

    public void setDao(Dao dao) {
        this.dao = dao;
    }

    public Service() {
        System.out.println("service constructor");

    }

    public void insert(User u)
    {
        dao.insert(u);
    }
    public User getuser(int employeeid)
    {
        return dao.getuser(employeeid);
    }
    public List<User> getuserdetails()
    {
        return dao.getuserdetails();
    }
    public boolean update(int employeeid, String name, double salary, char desig) {
        return dao.update(employeeid,name,salary,desig);
    }


}
