package mvc;

import basic.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class Presentation {
    @Autowired
    private Service ser;

    public Presentation() {
        System.out.println("presentation constructor");
    }

    public Service getSer() {
        return ser;
    }
    public void insert(User u)
    {
        ser.insert(u);
    }

    public void setSer(Service ser) {

        this.ser = ser;
    }
    public User getuser(int userid)
    {
        return ser.getuser(userid);
    }
    public List<User> getuserdetails()
    {
        return ser.getuserdetails();
    }
    public boolean update(int employeeid, String name, double salary, char desig) {
        return ser.update(employeeid,name,salary,desig);
    }

    /*@Override
    public String toString() {
        return "Presentation{" +
                "ser=" + ser +
                '}';*/
    }

