create table customerregist(custid number(15) primary key,names varchar2(20),dateofbirth varchar2(20),contactno varchar2(20),Emailadress varchar2(20),profession varchar2(20),monthlyexpanse number(10),designation varchar2(20),
companyname varchar2(20),monthlyincome number(20))
create table emis(EmiAmount number(15),emiduedate varchar2(20), status varchar2(10),principleComponent number(20),interstcomponent number(20), penaltycharges number(20))
create table singups(age number (15) , username varchar2(15),  passwords varchar2(15),mail varchar2(50),gender varchar2(10),location varchar2(20), hobbies varchar2(30),contactno number(15)) 
drop table Singups
create table registrationcustomers(age number (15) , username varchar2(15),  passwords varchar2(15),mail varchar2(50) Primary key,gender varchar2(10),role varchar2(10),contactno varchar2(15)) 
ALTER TABLE   registrationcustomers
MODIFY role VARCHAR2( 20 );
commit;
ALTER TABLE   registrationcustomers
create table mayankcustomers(age number (15) , username varchar2(15),  passwords varchar2(15),mail varchar2(50) Primary key,gender varchar2(10),income number(15), expenses number(15), qualification varchar2(20), experience number(15),contactno varchar2(15)) 
select * from mayankcustomers
create table mayankcustomer(dates date , username varchar2(15),  passwords varchar2(15),mail varchar2(50) Primary key,gender varchar2(10),income number(15), expenses number(15), qualification varchar2(20), experience number(15), profession varchar2(30),designation varchar2(20),companyname varchar2(20),contactno varchar2(15),customerId varchar2(100))
select * from mayankcustomer
drop table mayankcustomer
desc  mayankcustomer
create table mayankuser(dates date , username varchar2(15),  passwords varchar2(15),mail varchar2(50) Primary key,gender varchar2(10),role varchar2(20),contactno varchar2(15),userid varchar2(50)) 
select * from mayankuser
drop table mayankuser
create table mayankusers( names varchar2(20), empId number(15), salary number(20),desig varchar2(10));

select * from mayankusers
create table customerapplyloan(laoanamount number(10),tenure number(10), repaymentfrequency number(10),buildername varchar2(20),propertysize varchar2(20),propertyvalue varchar2(20),veichlecategory varchar2(20),modelno varchar2(30),manufacture varchar2(30),yearofmanf varchar2(20),assetvalue number(20)) 
desc customerapplyloan
create table mayankloan(loanid varchar2(20), customerid varchar2(20),loanamount number(10),loantype varchar2(20),roi number(10,2),emi number(10,2),eligibleloan number(10),dbr number(10,2),disbursedate date,
tenure number(10), repaymentfrequency number(10),buildername varchar2(20),propertysize varchar2(20),propertyvalue varchar2(20),veichlecategory varchar2(20),modelno varchar2(30),manufacture varchar2(30),yearofmanf varchar2(20),
assetvalue number(20),loanstatus varchar2(20))
drop table mayankloan

desc mayankloan